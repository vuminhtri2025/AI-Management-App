package com.aimanager.app

import android.app.Application
import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Project(val id: String, val name: String, val status: Int = 0) // 0 On-going, 1 Holding, 2 Completed
data class Ai(val id: String, val name: String, val cooldownUntil: Long, val projects: List<Project>)

fun Ai.running() = projects.any { it.status == 0 }
fun newId() = UUID.randomUUID().toString()
fun left(a: Ai, now: Long) = (a.cooldownUntil - now).coerceAtLeast(0)
fun fmt(ms: Long): String {
    val m = (ms + 59_999) / 60_000
    val d = m / 1440; val h = m % 1440 / 60; val p = m % 60
    return when {
        d > 0 -> "${d}n %02dg %02dp".format(h, p)
        h > 0 -> "${h}g %02dp".format(p)
        else -> "${p}p"
    }
}

private fun root(sp: SharedPreferences) = runCatching { JSONObject(sp.getString("j", "{}")!!) }.getOrDefault(JSONObject())

fun loadNotify(sp: SharedPreferences) = root(sp).optBoolean("notify", true)
fun loadPal(sp: SharedPreferences) = root(sp).optInt("pal", 0)
fun loadAis(sp: SharedPreferences): List<Ai> = runCatching {
    root(sp).optJSONArray("ais")?.let { a ->
        List(a.length()) { i ->
            val x = a.getJSONObject(i); val p = x.getJSONArray("p")
            Ai(x.getString("id"), x.getString("name"), x.getLong("cd"),
                List(p.length()) { j -> p.getJSONObject(j).let { Project(it.getString("id"), it.getString("n"), it.optInt("s", 0)) } })
        }
    }
}.getOrNull() ?: emptyList()

class AppVM(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("data", 0)
    var ais by mutableStateOf(loadAis(sp)); private set
    var pal by mutableIntStateOf(loadPal(sp)); private set
    var notify by mutableStateOf(loadNotify(sp)); private set
    var mode by mutableIntStateOf(root(sp).optInt("mode", 2)); private set

    private fun save() {
        val o = JSONObject().put("pal", pal).put("mode", mode).put("notify", notify)
            .put("ais", JSONArray().also { arr ->
                ais.forEach { a ->
                    arr.put(JSONObject().put("id", a.id).put("name", a.name).put("cd", a.cooldownUntil)
                        .put("p", JSONArray().also { pa -> a.projects.forEach { pa.put(JSONObject().put("id", it.id).put("n", it.name).put("s", it.status)) } }))
                }
            })
        sp.edit().putString("j", o.toString()).apply()
        AiWidget.refresh(getApplication())
        Notifier.sync(getApplication())
    }

    private fun ui(f: (List<Ai>) -> List<Ai>) { ais = f(ais); save() }
    private fun <T> List<T>.mv(a: Int, b: Int) = toMutableList().apply { add(b, removeAt(a)) }
    private fun upd(id: String, f: (Ai) -> Ai) = ui { l -> l.map { if (it.id == id) f(it) else it } }

    fun addAi(n: String) = ui { it + Ai(newId(), n, 0, emptyList()) }
    fun delAi(id: String) = ui { l -> l.filter { it.id != id } }
    fun renameAi(id: String, n: String) = upd(id) { it.copy(name = n) }
    fun renamePrj(id: String, pid: String, n: String) = upd(id) { it.copy(projects = it.projects.map { p -> if (p.id == pid) p.copy(name = n) else p }) }
    fun changePrjStatus(id: String, pid: String, s: Int) = upd(id) { it.copy(projects = it.projects.map { p -> if (p.id == pid) p.copy(status = s) else p }) }
    fun setCd(id: String, t: Long) = upd(id) { it.copy(cooldownUntil = t) }
    fun moveAi(a: Int, b: Int) = ui { it.mv(a, b) }
    fun addPrj(id: String, n: String) = upd(id) { it.copy(projects = it.projects + Project(newId(), n)) }
    fun delPrj(id: String, pid: String) = upd(id) { it.copy(projects = it.projects.filter { p -> p.id != pid }) }
    fun movePrj(id: String, a: Int, b: Int) = upd(id) { it.copy(projects = it.projects.mv(a, b)) }
    fun changePal(i: Int) { pal = i; save() }
    fun changeNotify(b: Boolean) { notify = b; save() }
    fun changeMode(m: Int) { mode = m; save() }
}
