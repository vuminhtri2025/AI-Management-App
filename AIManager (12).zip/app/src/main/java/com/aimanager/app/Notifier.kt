package com.aimanager.app

import android.Manifest
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.provider.Settings

/** Hẹn báo thức cho từng AI; khi hết thời gian hồi sẽ bắn thông báo (thường hoặc kiểu báo thức). */
object Notifier {
    const val ACTION = "com.aimanager.app.NOTIFY"
    const val CH = "cooldown"
    const val CH_LOUD = "cooldown_alarm"

    private fun pending(c: Context, id: String, name: String) = PendingIntent.getBroadcast(
        c, id.hashCode(),
        Intent(c, NotifyReceiver::class.java).setAction(ACTION).putExtra("id", id).putExtra("name", name),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "AI hồi xong", NotificationManager.IMPORTANCE_HIGH))
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        nm.createNotificationChannel(NotificationChannel(CH_LOUD, "AI hồi xong (âm báo thức)", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Kêu bằng âm lượng báo thức, kể cả khi điện thoại ở chế độ im lặng"
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 600)
            setBypassDnd(true)
        })
    }

    /** Mở cài đặt riêng của kênh báo thức (để bật "Đè lên Không làm phiền" nếu muốn). */
    fun openLoudSettings(c: Context) {
        ensureChannels(c)
        c.startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName).putExtra(Settings.EXTRA_CHANNEL_ID, CH_LOUD)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun sync(c: Context) {
        val sp = c.getSharedPreferences("data", 0)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val ais = loadAis(sp)
        val on = loadNotify(sp)
        val now = System.currentTimeMillis()
        val old = sp.getStringSet("n_ids", emptySet()) ?: emptySet()
        (old + ais.map { it.id }).forEach { am.cancel(pending(c, it, "")) }
        if (on) ais.filter { it.notify && it.cooldownUntil > now }.forEach {
            val pi = pending(c, it.id, it.name)
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.cooldownUntil, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.cooldownUntil, pi)
        }
        sp.edit().putStringSet("n_ids", ais.map { it.id }.toSet()).apply()
    }

    fun post(c: Context, ai: Ai) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        ensureChannels(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val b = Notification.Builder(c, if (ai.loud) CH_LOUD else CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("${ai.name} đã sẵn sàng")
            .setContentText(if (ai.projects.isEmpty()) "AI đã hồi xong" else "${ai.projects.size} dự án · bấm để mở")
            .setContentIntent(openAiIntent(c, ai.id.hashCode(), ai.id)).setAutoCancel(true)
        if (ai.loud) b.setCategory(Notification.CATEGORY_ALARM).setTimeoutAfter(60_000)
        val n = b.build()
        if (ai.loud) n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(ai.id.hashCode(), n)
    }
}

class NotifyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            Intent.ACTION_BOOT_COMPLETED -> { Notifier.sync(c); AiWidget.refresh(c) }
            Notifier.ACTION -> {
                val sp = c.getSharedPreferences("data", 0)
                if (!loadNotify(sp)) return
                val ai = loadAis(sp).firstOrNull { it.id == i.getStringExtra("id") } ?: return
                if (!ai.notify) return
                if (ai.cooldownUntil > System.currentTimeMillis() + 5000) return
                Notifier.post(c, ai)
                AiWidget.refresh(c)
            }
        }
    }
}
