package com.aimanager.app

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily

val Inter = FontFamily.Default // Roboto, giống app quản lý chấm công

/** (tên, màu chính, màu phụ) */
val palettes = listOf(
    Triple("Tím", 0xFF8B8BFF, 0xFF5C5CFF),
    Triple("Xanh ngọc", 0xFF3DD6C6, 0xFF1AA89A),
    Triple("Hồng", 0xFFFF7AC8, 0xFFD94FA0),
    Triple("Vàng", 0xFFFFC857, 0xFFE0A030),
)
val StatusCol = listOf(Color(0xFFFF4D6A), Color(0xFF7DD3FC), Color(0xFFC084FC))
val StatusName = listOf("Waiting token", "Stable", "Completed")
val Ready = Color(0xFF2ED47A)
val Wait = Color(0xFFFFB02E)

private fun Typography.withFont(f: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f), displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f), headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f), titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f), bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f), labelSmall = labelSmall.copy(fontFamily = f),
)

@Composable
fun AppTheme(pal: Int, dark: Boolean, content: @Composable () -> Unit) {
    val p = palettes[pal.coerceIn(0, palettes.lastIndex)]
    val scheme = if (dark) darkColorScheme(
        primary = Color(p.second), secondary = Color(p.third),
        background = Color(0xFF0A0A0D), surface = Color(0xFF17181D), surfaceVariant = Color(0xFF272932),
        onSurface = Color(0xFFF2F2F5), onSurfaceVariant = Color(0xFF9A9CA6), onPrimary = Color(0xFF0A0A0D)
    ) else lightColorScheme(
        primary = Color(p.third), secondary = Color(p.second),
        background = Color(0xFFF3F4F9), surface = Color.White, surfaceVariant = Color(0xFFE4E7F1),
        onSurface = Color(0xFF111522), onSurfaceVariant = Color(0xFF626B80), onPrimary = Color.White
    )
    MaterialTheme(colorScheme = scheme, typography = Typography().withFont(Inter)) {
        ProvideTextStyle(TextStyle(fontFamily = Inter), content)
    }
}
