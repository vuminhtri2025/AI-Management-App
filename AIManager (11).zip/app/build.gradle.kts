plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
val runNo = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
val buildCode = (System.currentTimeMillis() / 60000).toInt() // luôn tăng theo thời gian build
val ksFile = rootProject.file("release.keystore")

android {
    namespace = "com.aimanager.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aimanager.app"
        minSdk = 26
        targetSdk = 34
        versionCode = buildCode
        versionName = "1.0.$runNo"
    }
    signingConfigs {
        if (ksFile.exists()) create("fixed") {
            storeFile = ksFile
            storeType = "pkcs12"
            storePassword = "aimanager"
            keyAlias = "aimanager"
            keyPassword = "aimanager"
        }
    }
    buildTypes {
        debug { if (ksFile.exists()) signingConfig = signingConfigs.getByName("fixed") }
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(bom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("com.google.android.material:material:1.12.0")
}
