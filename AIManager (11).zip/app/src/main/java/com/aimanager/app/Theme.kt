package com.aimanager.app

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily

val Inter = FontFamily.Default // Roboto / system-ui

val palettes = listOf(Triple("Xám", 0xFFE6E8EC, 0xFFB5BBC5))

val Mint = Color(0xFF7EE2A8)      // bật / sẵn sàng
val Pink = Color(0xFFF4A3A3)      // dừng / đang hồi / xóa
val Sub1 = Color(0xFFB5BBC5)      // chữ phụ
val Sub2 = Color(0xFF9AA1AD)      // ghi chú
val StatusCol = listOf(Pink, Color(0xFF8EC5F4), Sub2)
val StatusName = listOf("Waiting token", "Stable", "Completed")
val Ready = Mint
val Wait = Pink

/** Nền: gradient dọc */
val BgBrush = Brush.verticalGradient(listOf(Color(0xFF3B4048), Color(0xFF16181C)))
/** Thẻ: gradient chéo */
val CardBrush = Brush.linearGradient(listOf(Color(0xFF5A606B), Color(0xFF2A2E35)))

private fun Typography.withFont(f: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = f), displayMedium = displayMedium.copy(fontFamily = f), displaySmall = displaySmall.copy(fontFamily = f),
    headlineLarge = headlineLarge.copy(fontFamily = f), headlineMedium = headlineMedium.copy(fontFamily = f), headlineSmall = headlineSmall.copy(fontFamily = f),
    titleLarge = titleLarge.copy(fontFamily = f), titleMedium = titleMedium.copy(fontFamily = f), titleSmall = titleSmall.copy(fontFamily = f),
    bodyLarge = bodyLarge.copy(fontFamily = f), bodyMedium = bodyMedium.copy(fontFamily = f), bodySmall = bodySmall.copy(fontFamily = f),
    labelLarge = labelLarge.copy(fontFamily = f), labelMedium = labelMedium.copy(fontFamily = f), labelSmall = labelSmall.copy(fontFamily = f),
)

@Composable
fun AppTheme(pal: Int, dark: Boolean, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Color(0xFFE6E8EC), onPrimary = Color(0xFF1B1D22),
        secondary = Sub1, onSecondary = Color(0xFF1B1D22),
        background = Color(0xFF16181C), onBackground = Color.White,
        surface = Color(0xFF2A2E35), onSurface = Color.White,
        surfaceVariant = Color(0xFF3A3F47), onSurfaceVariant = Sub1,
        outline = Color.White.copy(alpha = .3f), error = Pink
    )
    MaterialTheme(colorScheme = scheme, typography = Typography().withFont(Inter)) {
        ProvideTextStyle(TextStyle(fontFamily = Inter), content)
    }
}
