package com.aimanager.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.widget.RemoteViews

/** Widget danh sách: hiển thị tất cả AI, kéo giãn để đổi cỡ, cuộn lên xuống khi có nhiều AI. */
class AiListWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = ids.forEach { draw(c, m, it) }
    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) = draw(c, m, id)
    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACTION) AiWidget.refresh(c)
    }

    companion object {
        const val ACTION = "com.aimanager.app.REFRESH_LIST"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(ComponentName(c, AiListWidget::class.java)).forEach { draw(c, m, it) }
        }

        fun draw(c: Context, m: AppWidgetManager, id: Int) {
            val ais = loadAis(c.getSharedPreferences("data", 0))
            val rv = RemoteViews(c.packageName, R.layout.ai_list_widget)
            rv.setOnClickPendingIntent(R.id.l_header, PendingIntent.getActivity(c, 0,
                Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            rv.setTextViewText(R.id.l_count, "${ais.size} AI")

            val svc = Intent(c, AiListService::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
            rv.setRemoteAdapter(R.id.l_list, svc)
            rv.setEmptyView(R.id.l_list, R.id.l_empty)
            rv.setPendingIntentTemplate(R.id.l_list, PendingIntent.getActivity(c, 1,
                Intent(c, MainActivity::class.java), PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))

            Tick.schedule(c)
            m.updateAppWidget(id, rv)
            m.notifyAppWidgetViewDataChanged(id, R.id.l_list)
        }
    }
}

/** Tên các dự án chưa Completed (Waiting token đỏ, Stable xanh dương nhạt); không có thì hiện "Free". */
fun activeText(ai: Ai, sep: String): CharSequence {
    val act = ai.active()
    if (act.isEmpty()) return "Free"
    val sb = SpannableStringBuilder()
    act.forEachIndexed { i, p ->
        if (i > 0) sb.append(sep)
        val st = sb.length
        sb.append(p.name)
        sb.setSpan(ForegroundColorSpan(if (p.status == 0) 0xFFF4A3A3.toInt() else 0xFF8EC5F4.toInt()), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    return sb
}

fun nameColor(ai: Ai?): String = when (ai?.hotStatus()) { 0 -> "#F4A3A3"; 1 -> "#8EC5F4"; else -> "#FFFFFF" }

/** Mở app; nếu có aiId thì vào thẳng trang của AI đó. */
fun openAiIntent(c: Context, key: Int, aiId: String?): PendingIntent {
    val i = Intent(c, MainActivity::class.java).putExtra("ai", aiId)
    i.data = Uri.parse("aim://open/${aiId ?: "home"}/$key")
    return PendingIntent.getActivity(c, key, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}
