package com.aimanager.app

import android.app.Application
import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Todo(val id: String, val text: String, val createdAt: Long, val done: Boolean = false, val doneAt: Long = 0)
data class Project(val id: String, val name: String, val status: Int = 0, val todos: List<Todo> = emptyList()) // 0 On-going, 1 Holding, 2 Completed
data class Ai(val id: String, val name: String, val cooldownUntil: Long, val projects: List<Project>)

fun Ai.active() = projects.filter { it.status != 2 }
/** 0 = có dự án Waiting token (đỏ), 1 = chỉ có Stable (xanh dương nhạt), null = không highlight */
fun Ai.hotStatus(): Int? = when {
    projects.any { it.status == 0 } -> 0
    projects.any { it.status == 1 } -> 1
    else -> null
}
fun Ai.running() = projects.any { it.status == 0 }
fun newId() = UUID.randomUUID().toString()
fun left(a: Ai, now: Long) = (a.cooldownUntil - now).coerceAtLeast(0)
fun fmt(ms: Long): String {
    val m = (ms + 59_999) / 60_000
    val d = m / 1440; val h = m % 1440 / 60; val p = m % 60
    return when {
        d > 0 -> "${d}n %02dg %02dp".format(h, p)
        h > 0 -> "${h}g %02dp".format(p)
        else -> "${p}p"
    }
}

private fun root(sp: SharedPreferences) = runCatching { JSONObject(sp.getString("j", "{}")!!) }.getOrDefault(JSONObject())

fun loadNotify(sp: SharedPreferences) = root(sp).optBoolean("notify", true)
private fun parseTodos(o: JSONObject): List<Todo> = o.optJSONArray("t")?.let { a ->
    List(a.length()) { i -> a.getJSONObject(i).let { Todo(it.getString("id"), it.getString("x"), it.getLong("c"), it.optBoolean("d"), it.optLong("da")) } }
} ?: emptyList()

fun loadPal(sp: SharedPreferences) = root(sp).optInt("pal", 0)
fun loadAis(sp: SharedPreferences): List<Ai> = runCatching {
    root(sp).optJSONArray("ais")?.let { a ->
        List(a.length()) { i ->
            val x = a.getJSONObject(i); val p = x.getJSONArray("p")
            Ai(x.getString("id"), x.getString("name"), x.getLong("cd"),
                List(p.length()) { j -> p.getJSONObject(j).let { Project(it.getString("id"), it.getString("n"), it.optInt("s", 0), parseTodos(it)) } })
        }
    }
}.getOrNull() ?: emptyList()

class AppVM(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("data", 0)
    var ais by mutableStateOf(loadAis(sp)); private set
    var pal by mutableIntStateOf(loadPal(sp)); private set
    var fs by mutableIntStateOf(root(sp).optInt("fs", 1)); private set
    var notify by mutableStateOf(loadNotify(sp)); private set
    var mode by mutableIntStateOf(root(sp).optInt("mode", 2)); private set

    private fun save() {
        val o = JSONObject().put("pal", pal).put("mode", mode).put("fs", fs).put("notify", notify)
            .put("ais", JSONArray().also { arr ->
                ais.forEach { a ->
                    arr.put(JSONObject().put("id", a.id).put("name", a.name).put("cd", a.cooldownUntil)
                        .put("p", JSONArray().also { pa -> a.projects.forEach { pa.put(JSONObject().put("id", it.id).put("n", it.name).put("s", it.status).put("t", JSONArray().also { ta -> it.todos.forEach { t -> ta.put(JSONObject().put("id", t.id).put("x", t.text).put("c", t.createdAt).put("d", t.done).put("da", t.doneAt)) } })) } }))
                }
            })
        sp.edit().putString("j", o.toString()).apply()
        AiWidget.refresh(getApplication())
        Notifier.sync(getApplication())
    }

    private fun ui(f: (List<Ai>) -> List<Ai>) { ais = f(ais); save() }
    private fun <T> List<T>.mv(a: Int, b: Int) = toMutableList().apply { add(b, removeAt(a)) }
    private fun upd(id: String, f: (Ai) -> Ai) = ui { l -> l.map { if (it.id == id) f(it) else it } }

    fun addAi(n: String) = ui { it + Ai(newId(), n, 0, emptyList()) }
    fun delAi(id: String) = ui { l -> l.filter { it.id != id } }
    fun renameAi(id: String, n: String) = upd(id) { it.copy(name = n) }
    fun renamePrj(id: String, pid: String, n: String) = upd(id) { it.copy(projects = it.projects.map { p -> if (p.id == pid) p.copy(name = n) else p }) }
    fun changePrjStatus(id: String, pid: String, s: Int) = upd(id) { it.copy(projects = it.projects.map { p -> if (p.id == pid) p.copy(status = s) else p }) }
    private fun updPrj(id: String, pid: String, f: (Project) -> Project) = upd(id) { a -> a.copy(projects = a.projects.map { if (it.id == pid) f(it) else it }) }
    fun addTodo(id: String, pid: String, t: String) = updPrj(id, pid) { it.copy(todos = it.todos + Todo(newId(), t, System.currentTimeMillis())) }
    fun toggleTodo(id: String, pid: String, tid: String) = updPrj(id, pid) { p ->
        p.copy(todos = p.todos.map { if (it.id != tid) it else if (it.done) it.copy(done = false, doneAt = 0) else it.copy(done = true, doneAt = System.currentTimeMillis()) })
    }
    fun editTodo(id: String, pid: String, tid: String, text: String) = updPrj(id, pid) { p -> p.copy(todos = p.todos.map { if (it.id == tid) it.copy(text = text) else it }) }
    fun delTodo(id: String, pid: String, tid: String) = updPrj(id, pid) { p -> p.copy(todos = p.todos.filter { it.id != tid }) }
    fun setCd(id: String, t: Long) = upd(id) { it.copy(cooldownUntil = t) }
    fun moveAi(a: Int, b: Int) = ui { it.mv(a, b) }
    fun addPrj(id: String, n: String) = upd(id) { it.copy(projects = it.projects + Project(newId(), n)) }
    fun delPrj(id: String, pid: String) = upd(id) { it.copy(projects = it.projects.filter { p -> p.id != pid }) }
    fun movePrj(id: String, a: Int, b: Int) = upd(id) { it.copy(projects = it.projects.mv(a, b)) }
    fun changePal(i: Int) { pal = i; save() }
    fun changeNotify(b: Boolean) { notify = b; save() }
    fun changeFs(i: Int) { fs = i; save() }
    fun changeMode(m: Int) { mode = m; save() }
}
