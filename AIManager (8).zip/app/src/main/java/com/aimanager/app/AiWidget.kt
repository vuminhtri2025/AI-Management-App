package com.aimanager.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews

/** Widget màn hình chính: mỗi widget gắn với 1 AI (chọn khi thêm), kéo giãn để đổi cỡ. */
class AiWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = ids.forEach { draw(c, m, it) }
    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) = draw(c, m, id)
    override fun onDeleted(c: Context, ids: IntArray) {
        val e = c.getSharedPreferences("data", 0).edit(); ids.forEach { e.remove("w_$it") }; e.apply()
    }
    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACTION) refresh(c)
    }

    companion object {
        const val ACTION = "com.aimanager.app.REFRESH"

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(ComponentName(c, AiWidget::class.java)).forEach { draw(c, m, it) }
            AiListWidget.refresh(c)
        }

        fun draw(c: Context, m: AppWidgetManager, id: Int) {
            Tick.schedule(c)
            val sp = c.getSharedPreferences("data", 0)
            val ai = loadAis(sp).firstOrNull { it.id == sp.getString("w_$id", null) }
            val accent = Color.parseColor("#%08X".format(palettes[loadPal(sp).coerceIn(0, palettes.lastIndex)].second))
            val h = m.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 100)
            val w = m.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 150)
            val rv = RemoteViews(c.packageName, R.layout.ai_widget)

            rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 0,
                Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            rv.setTextColor(R.id.w_name, Color.parseColor(nameColor(ai)))

            if (ai == null) {
                rv.setTextViewText(R.id.w_name, "AI không tồn tại")
                listOf(R.id.w_time, R.id.w_ready, R.id.w_info, R.id.w_proj).forEach { rv.setViewVisibility(it, View.GONE) }
                m.updateAppWidget(id, rv); return
            }
            val now = System.currentTimeMillis()
            val rest = left(ai, now)
            val ready = rest == 0L
            val col = if (ready) Color.parseColor("#00E676") else Color.parseColor("#FFB74D")
            rv.setTextViewText(R.id.w_name, ai.name)

            val big = if (w < 150) 22f else if (h < 100) 26f else if (h < 170) 32f else 40f
            rv.setTextViewTextSize(R.id.w_time, TypedValue.COMPLEX_UNIT_SP, big)
            rv.setTextViewTextSize(R.id.w_ready, TypedValue.COMPLEX_UNIT_SP, big * .7f)
            rv.setTextColor(R.id.w_time, col); rv.setTextColor(R.id.w_ready, col)

            rv.setViewVisibility(R.id.w_ready, if (ready) View.VISIBLE else View.GONE)
            rv.setViewVisibility(R.id.w_time, if (ready) View.GONE else View.VISIBLE)
            if (!ready) rv.setTextViewText(R.id.w_time, fmt(rest))

            val large = h >= 170 && ai.active().isNotEmpty()
            rv.setViewVisibility(R.id.w_info, if (h >= 80 && !large) View.VISIBLE else View.GONE)
            rv.setTextViewText(R.id.w_info, activeText(ai, " · "))
            rv.setViewVisibility(R.id.w_proj, if (large) View.VISIBLE else View.GONE)
            rv.setTextViewText(R.id.w_proj, activeText(ai, "\n"))
            m.updateAppWidget(id, rv)
        }
    }
}
