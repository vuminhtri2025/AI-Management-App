package com.aimanager.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService

/** Cấp dữ liệu cho danh sách cuộn được trong widget "Tất cả AI". */
class AiListService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    class Factory(private val c: Context) : RemoteViewsFactory {
        private var ais = emptyList<Ai>()
        override fun onCreate() {}
        override fun onDataSetChanged() { ais = loadAis(c.getSharedPreferences("data", 0)) }
        override fun onDestroy() {}
        override fun getCount() = ais.size
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = ais.getOrNull(position)?.id.hashCode().toLong()
        override fun hasStableIds() = true

        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.ai_list_item)
            val ai = ais.getOrNull(position) ?: return rv
            val rest = left(ai, System.currentTimeMillis())
            val ready = rest == 0L
            rv.setTextViewText(R.id.i_name, ai.name)
            rv.setTextColor(R.id.i_name, Color.parseColor(nameColor(ai)))
            rv.setTextViewText(R.id.i_sub, activeText(ai, " · "))
            rv.setTextViewText(R.id.i_status, if (ready) "● Sẵn sàng" else "● Đang hồi")
            rv.setTextColor(R.id.i_status, Color.parseColor(if (ready) "#2ED47A" else "#FFB02E"))
            rv.setViewVisibility(R.id.i_time, if (ready) View.GONE else View.VISIBLE)
            if (!ready) rv.setTextViewText(R.id.i_time, fmt(rest))
            rv.setOnClickFillInIntent(R.id.i_root, Intent())
            return rv
        }
    }
}
