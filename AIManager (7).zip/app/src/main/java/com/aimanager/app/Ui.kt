package com.aimanager.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import java.time.*

private val cs @Composable get() = MaterialTheme.colorScheme
private val line @Composable get() = cs.onSurface.copy(alpha = .1f)
private val tnum = TextStyle(fontFeatureSettings = "tnum")

@Composable
fun Root(vm: AppVM) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { val t = System.currentTimeMillis(); now = t; delay(1000 - t % 1000) } }
    var screen by rememberSaveable { mutableStateOf("home") }
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val ask: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { if (vm.notify) ask() }
    BackHandler(screen != "home") { screen = if (screen.startsWith("p:")) screen.split(":")[1] else "home" }
    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        when (screen) {
            "home" -> Home(vm, now, { screen = it }, { screen = "settings" })
            "settings" -> SettingsScreen(vm, ask) { screen = "home" }
            else -> if (screen.startsWith("p:")) {
                val parts = screen.split(":")
                val ai = vm.ais.firstOrNull { it.id == parts[1] }
                val p = ai?.projects?.firstOrNull { it.id == parts[2] }
                if (ai == null || p == null) { screen = "home" } else { ProjectScreen(vm, ai, p) { screen = ai.id } }
            } else {
                val ai = vm.ais.firstOrNull { it.id == screen }
                if (ai == null) { screen = "home" } else { Detail(vm, ai, now, { screen = "p:${ai.id}:$it" }) { screen = "home" } }
            }
        }
    }
}

// ---------- thành phần dùng chung ----------

@Composable
fun Dots(tint: Color) = androidx.compose.foundation.Canvas(Modifier.size(18.dp, 26.dp)) {
    val r = 2.4.dp.toPx()
    for (x in 0..1) for (y in 0..2) drawCircle(tint, r, Offset(size.width * (.25f + .5f * x), size.height * (.15f + .35f * y)))
}

@Composable
fun Pill(ready: Boolean, big: Boolean = false) {
    val c = if (ready) Ready else Wait
    Row(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .16f)).padding(horizontal = if (big) 14.dp else 10.dp, vertical = if (big) 8.dp else 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(c, CircleShape)); Spacer(Modifier.width(8.dp))
        Text(if (ready) "Sẵn sàng" else "Đang hồi", color = c, fontWeight = FontWeight.SemiBold, fontSize = if (big) 15.sp else 13.sp)
    }
}

@Composable
fun Chip(text: String, status: Int, main: Boolean) {
    val c = StatusCol[status]
    Text((if (main) "★ " else "") + text, color = c, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        textDecoration = if (status == 2) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = if (main) .22f else .12f)).padding(horizontal = 12.dp, vertical = 5.dp))
}

@Composable
fun StatusPill(status: Int, onChange: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val c = StatusCol[status]
    Box {
        Row(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .16f)).clickable { open = true }
            .padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(c, CircleShape)); Spacer(Modifier.width(6.dp))
            Text(StatusName[status], color = c, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Icon(Icons.Default.ArrowDropDown, null, tint = c, modifier = Modifier.size(20.dp))
        }
        DropdownMenu(open, { open = false }) {
            StatusName.forEachIndexed { i, n ->
                DropdownMenuItem(text = { Text(n, color = StatusCol[i], fontWeight = FontWeight.SemiBold) }, onClick = { onChange(i); open = false })
            }
        }
    }
}

@Composable
fun BigButton(text: String, onClick: () -> Unit) =
    Button(onClick, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp),
        colors = ButtonDefaults.buttonColors(containerColor = cs.primary, contentColor = cs.onPrimary)) {
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }

@Composable
fun Segmented(opts: List<String>, sel: Int, on: (Int) -> Unit) =
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surface).padding(6.dp)) {
        opts.forEachIndexed { i, t ->
            Box(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(if (sel == i) cs.surfaceVariant else Color.Transparent)
                .clickable { on(i) }.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                Text(t, color = if (sel == i) cs.onSurface else cs.onSurfaceVariant, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
    }

@Composable
fun EditBtn(onClick: () -> Unit) =
    IconButton(onClick, Modifier.size(30.dp)) { Icon(Icons.Default.Edit, "Sửa tên", tint = cs.onSurfaceVariant, modifier = Modifier.size(15.dp)) }

@Composable
fun TopBar(title: String, back: () -> Unit, onEdit: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) =
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(back) { Icon(Icons.Default.ArrowBack, null, tint = cs.onSurface) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
        if (onEdit != null) EditBtn(onEdit)
        Spacer(Modifier.weight(1f))
        trailing()
    }

// ---------- trang chủ ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Home(vm: AppVM, now: Long, open: (String) -> Unit, settings: () -> Unit) {
    val ls = rememberLazyListState()
    val drag = remember { DragCtl(ls, 2) { a, b -> vm.moveAi(a, b) } }
    var addAi by remember { mutableStateOf(false) }
    var editAi by remember { mutableStateOf<Ai?>(null) }
    val active = vm.ais.sumOf { a -> a.projects.count { it.status == 0 } }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(state = ls, modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item(key = "h") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("AI Manager", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, letterSpacing = (-0.5).sp)
                        Text("${vm.ais.size} AI · $active dự án đang chờ token", fontSize = 14.sp, color = cs.onSurfaceVariant)
                    }
                    IconButton(settings) { Icon(Icons.Default.Settings, null, tint = cs.onSurfaceVariant) }
                }
            }
            item(key = "hint") {
                Text(if (vm.ais.isEmpty()) "Chưa có AI nào. Bấm \"Thêm AI\" để bắt đầu." else "Giữ và kéo cụm chấm bên trái để sắp xếp",
                    fontSize = 13.sp, color = cs.onSurfaceVariant)
            }
            itemsIndexed(vm.ais, key = { _, a -> a.id }) { i, a -> AiCard(a, i, now, drag, { editAi = a }) { open(a.id) } }
        }
        Box(Modifier.padding(20.dp, 8.dp, 20.dp, 16.dp)) { BigButton("+  Thêm AI") { addAi = true } }
    }
    if (addAi) TextDialog("Thêm AI", "Tên AI", { addAi = false }) { vm.addAi(it); addAi = false }
    editAi?.let { e -> TextDialog("Sửa tên AI", "Tên AI", { editAi = null }, e.name) { vm.renameAi(e.id, it); editAi = null } }
}

@Composable
fun AiCard(a: Ai, i: Int, now: Long, drag: DragCtl, onEdit: () -> Unit, onClick: () -> Unit) {
    val ready = left(a, now) == 0L
    val shape = RoundedCornerShape(20.dp)
    val hs = a.hotStatus()
    val hot = hs != null
    val hc = StatusCol[hs ?: 0]
    val act = a.active()
    Row(
        Modifier.fillMaxWidth().zIndex(if (drag.dragging == i) 1f else 0f)
            .graphicsLayer { translationY = if (drag.dragging == i) drag.dy else 0f }
            .clip(shape)
            .background(cs.surface, shape)
            .background(if (hot) Brush.linearGradient(listOf(hc.copy(alpha = .22f), Color.Transparent)) else SolidColor(Color.Transparent), shape)
            .border(if (hot) 1.5.dp else 1.dp, if (hot) SolidColor(hc.copy(alpha = .85f)) else SolidColor(line), shape)
            .clickable(onClick = onClick).padding(start = 4.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(36.dp, 44.dp).dragHandle(a.id, i, drag), contentAlignment = Alignment.Center) { Dots(cs.onSurfaceVariant.copy(alpha = .8f)) }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(a.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                EditBtn(onEdit)
            }
            if (act.isEmpty()) Text("Free", fontSize = 13.sp, color = cs.onSurfaceVariant)
            else Text(buildAnnotatedString {
                act.forEachIndexed { j, p ->
                    if (j > 0) append(" · ")
                    withStyle(SpanStyle(color = StatusCol[p.status], fontWeight = FontWeight.SemiBold)) { append(p.name) }
                }
            }, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Pill(ready)
            if (!ready) Text(fmt(left(a, now)), style = tnum, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp, end = 2.dp))
        }
    }
}

// ---------- hộp thoại ----------

@Composable
fun TextDialog(title: String, hint: String, close: () -> Unit, init: String = "", ok: (String) -> Unit) {
    var t by remember { mutableStateOf(init) }
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(26.dp), containerColor = cs.surface, title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { OutlinedTextField(t, { t = it }, label = { Text(hint) }, singleLine = true, shape = RoundedCornerShape(16.dp)) },
        confirmButton = { TextButton({ if (t.isNotBlank()) ok(t.trim()) }) { Text("OK", fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(close) { Text("Hủy") } })
}

@Composable
private fun PickField(label: String, value: String, onClick: () -> Unit) =
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surfaceVariant).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text(label, color = cs.onSurfaceVariant, fontSize = 13.sp)
        Text(value, color = cs.onSurface, fontSize = 18.sp, fontWeight = FontWeight.Bold, style = tnum)
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CooldownPicker(onDone: (Long) -> Unit, close: () -> Unit) {
    val zone = ZoneId.systemDefault()
    var date by remember { mutableStateOf(LocalDate.now()) }
    var time by remember { mutableStateOf(LocalTime.now().withSecond(0).withNano(0)) }
    var showD by remember { mutableStateOf(false) }
    var showT by remember { mutableStateOf(false) }
    val target = LocalDateTime.of(date, time).atZone(zone).toInstant().toEpochMilli()
    val now = System.currentTimeMillis()
    val valid = target > now
    val today = LocalDate.now()
    val dText = "%02d/%02d/%d".format(date.dayOfMonth, date.monthValue, date.year).let {
        when (date) { today -> "Hôm nay · $it"; today.plusDays(1) -> "Ngày mai · $it"; else -> it }
    }
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(26.dp), containerColor = cs.surface,
        title = { Text("Giờ hồi chính xác", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PickField("Ngày", dText) { showD = true }
                PickField("Giờ", "%02d:%02d".format(time.hour, time.minute)) { showT = true }
                Text(if (valid) "Còn " + fmt(target - now) else "Thời điểm này đã qua, hãy chọn lại",
                    color = if (valid) cs.onSurfaceVariant else Wait, fontSize = 14.sp)
            }
        },
        confirmButton = { TextButton({ onDone(target) }, enabled = valid) { Text("Đặt", fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(close) { Text("Hủy") } })
    if (showD) {
        val st = rememberDatePickerState(initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(onDismissRequest = { showD = false },
            confirmButton = {
                TextButton({ st.selectedDateMillis?.let { date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() }; showD = false }) { Text("OK") }
            },
            dismissButton = { TextButton({ showD = false }) { Text("Hủy") } }) { DatePicker(st) }
    }
    if (showT) {
        val ts = rememberTimePickerState(time.hour, time.minute, true)
        AlertDialog(onDismissRequest = { showT = false }, shape = RoundedCornerShape(26.dp), containerColor = cs.surface,
            title = { Text("Chọn giờ", fontWeight = FontWeight.Bold) },
            text = { TimePicker(ts) },
            confirmButton = { TextButton({ time = LocalTime.of(ts.hour, ts.minute); showT = false }) { Text("OK") } },
            dismissButton = { TextButton({ showT = false }) { Text("Hủy") } })
    }
}

// ---------- chi tiết AI ----------

@Composable
fun Detail(vm: AppVM, a: Ai, now: Long, openPrj: (String) -> Unit, back: () -> Unit) {
    val ls = rememberLazyListState()
    val drag = remember(a.id) { DragCtl(ls, 3) { x, y -> vm.movePrj(a.id, x, y) } }
    var pick by remember { mutableStateOf(false) }
    var add by remember { mutableStateOf(false) }
    var editA by remember { mutableStateOf(false) }
    var editP by remember { mutableStateOf<Project?>(null) }
    val ready = left(a, now) == 0L
    val col = if (ready) Ready else Wait
    Column(Modifier.fillMaxSize()) {
        LazyColumn(state = ls, modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item(key = "bar") {
                TopBar(a.name, back, { editA = true }) { IconButton({ vm.delAi(a.id); back() }) { Icon(Icons.Default.Delete, null, tint = cs.onSurfaceVariant) } }
            }
            item(key = "st") {
                val shape = RoundedCornerShape(26.dp)
                Column(Modifier.fillMaxWidth().clip(shape).background(cs.surface).border(1.dp, line, shape).padding(20.dp)) {
                    Pill(ready, big = true)
                    if (!ready) {
                        Text(fmt(left(a, now)), style = tnum, color = col, fontSize = 36.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                        val t = Instant.ofEpochMilli(a.cooldownUntil).atZone(ZoneId.systemDefault())
                        Text("Hồi lúc %02d:%02d · %02d/%02d/%d".format(t.hour, t.minute, t.dayOfMonth, t.monthValue, t.year), color = cs.onSurfaceVariant, fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button({ pick = true }, shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = cs.primary, contentColor = cs.onPrimary)) { Text("Chọn giờ hồi", fontWeight = FontWeight.SemiBold) }
                        if (!ready) OutlinedButton({ vm.setCd(a.id, 0) }, shape = RoundedCornerShape(18.dp)) { Text("Đặt sẵn sàng", fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
            item(key = "pt") {
                Text("Dự án · kéo để sắp xếp, ★ là dự án chính", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
            }
            itemsIndexed(a.projects, key = { _, p -> p.id }) { i, p ->
                val shape = RoundedCornerShape(22.dp)
                Row(
                    Modifier.fillMaxWidth().zIndex(if (drag.dragging == i) 1f else 0f)
                        .graphicsLayer { translationY = if (drag.dragging == i) drag.dy else 0f }
                        .clip(shape).background(cs.surface).border(1.dp, if (i == 0) cs.primary.copy(alpha = .5f) else line, shape)
                        .clickable { openPrj(p.id) }
                        .padding(start = 6.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(40.dp, 48.dp).dragHandle(p.id, i, drag), contentAlignment = Alignment.Center) { Dots(cs.onSurfaceVariant.copy(alpha = .8f)) }
                    Text(if (i == 0) "★" else "${i + 1}", color = if (i == 0) cs.primary else cs.onSurfaceVariant, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = cs.onSurface, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusPill(p.status) { vm.changePrjStatus(a.id, p.id, it) }
                            if (p.todos.isNotEmpty()) Text("  ${p.todos.count { !it.done }}/${p.todos.size} việc", fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                    }
                    EditBtn { editP = p }
                    IconButton({ vm.delPrj(a.id, p.id) }) { Icon(Icons.Default.Close, null, tint = cs.onSurfaceVariant) }
                }
            }
        }
        Box(Modifier.padding(20.dp, 8.dp, 20.dp, 16.dp)) { BigButton("+  Thêm dự án") { add = true } }
    }
    if (pick) CooldownPicker({ vm.setCd(a.id, it); pick = false }) { pick = false }
    if (add) TextDialog("Thêm dự án", "Tên dự án", { add = false }) { vm.addPrj(a.id, it); add = false }
    if (editA) TextDialog("Sửa tên AI", "Tên AI", { editA = false }, a.name) { vm.renameAi(a.id, it); editA = false }
    editP?.let { p -> TextDialog("Sửa tên dự án", "Tên dự án", { editP = null }, p.name) { vm.renamePrj(a.id, p.id, it); editP = null } }
}

// ---------- todo của dự án ----------

@Composable
fun TodoRow(t: Todo, onToggle: () -> Unit, onDelete: () -> Unit) {
    val d = Instant.ofEpochMilli(t.createdAt).atZone(ZoneId.systemDefault())
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(32.dp).clickable(onClick = onToggle), contentAlignment = Alignment.Center) {
                Box(Modifier.size(20.dp).clip(RoundedCornerShape(6.dp)).background(if (t.done) cs.primary else Color.Transparent)
                    .border(1.5.dp, if (t.done) cs.primary else cs.onSurfaceVariant.copy(alpha = .6f), RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center) {
                    if (t.done) Icon(Icons.Default.Check, null, tint = cs.onPrimary, modifier = Modifier.size(14.dp))
                }
            }
            Spacer(Modifier.width(8.dp))
            Text(t.text, modifier = Modifier.weight(1f).padding(top = 6.dp), fontSize = 14.sp, lineHeight = 19.sp,
                color = if (t.done) cs.onSurfaceVariant else cs.onSurface,
                textDecoration = if (t.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null)
            Text("${d.monthValue}/${d.dayOfMonth}", style = tnum, fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 9.dp))
            Box(Modifier.size(32.dp).clickable(onClick = onDelete), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Close, "Xóa", tint = cs.onSurfaceVariant.copy(alpha = .6f), modifier = Modifier.size(16.dp))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(line))
    }
}

@Composable
fun ProjectScreen(vm: AppVM, ai: Ai, p: Project, back: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val open = p.todos.filter { !it.done }.sortedByDescending { it.createdAt }
    val done = p.todos.filter { it.done }.sortedByDescending { it.doneAt }
    fun add() { if (text.isNotBlank()) { vm.addTodo(ai.id, p.id, text.trim()); text = "" } }
    Column(Modifier.fillMaxSize().imePadding()) {
        TopBar(p.name, back)
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(ai.name, color = cs.onSurfaceVariant, fontSize = 13.sp)
            Spacer(Modifier.width(10.dp))
            StatusPill(p.status) { vm.changePrjStatus(ai.id, p.id, it) }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 12.dp)) {
            item(key = "h1") { Text("CẦN LÀM · ${open.size}", color = cs.onSurfaceVariant, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 4.dp)) }
            if (open.isEmpty()) item(key = "empty") { Text("Chưa có việc nào", color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp)) }
            items(open, key = { it.id }) { t -> TodoRow(t, { vm.toggleTodo(ai.id, p.id, t.id) }, { vm.delTodo(ai.id, p.id, t.id) }) }
            if (done.isNotEmpty()) {
                item(key = "h2") { Text("HOÀN THÀNH · ${done.size}", color = cs.onSurfaceVariant, fontSize = 12.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 20.dp, bottom = 4.dp)) }
                items(done, key = { it.id }) { t -> TodoRow(t, { vm.toggleTodo(ai.id, p.id, t.id) }, { vm.delTodo(ai.id, p.id, t.id) }) }
            }
        }
        Row(Modifier.padding(16.dp, 8.dp, 16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Thêm việc cần làm…", fontSize = 14.sp) },
                textStyle = TextStyle(fontSize = 14.sp), shape = RoundedCornerShape(24.dp), maxLines = 3,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), keyboardActions = KeyboardActions(onDone = { add() }))
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(48.dp).clip(CircleShape).background(cs.primary).clickable { add() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, "Thêm", tint = cs.onPrimary)
            }
        }
    }
}

// ---------- cài đặt ----------

@Composable
fun SettingsScreen(vm: AppVM, ask: () -> Unit, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TopBar("Cài đặt", back)
        Column(Modifier.padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Giao diện", color = cs.onSurfaceVariant, fontSize = 14.sp)
            Segmented(listOf("Tự động", "Sáng", "Tối"), vm.mode) { vm.changeMode(it) }
            Text("Cỡ chữ", color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Segmented(listOf("Nhỏ", "Vừa", "Lớn"), vm.fs) { vm.changeFs(it) }
            Text("Màu chủ đạo", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                palettes.forEachIndexed { i, p ->
                    Box(Modifier.size(52.dp).clip(CircleShape).background(Color(p.second))
                        .border(if (vm.pal == i) 3.dp else 0.dp, cs.onSurface, CircleShape).clickable { vm.changePal(i) })
                }
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Thông báo khi AI hồi xong", color = cs.onSurface, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Switch(vm.notify, { vm.changeNotify(it); if (it) ask() })
            }
            Text("Widget", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Text("Giữ lâu màn hình chính → Widget → AI Manager. Có 2 loại: \"Một AI\" và \"Tất cả AI\" (danh sách). Kéo giãn widget để đổi kích thước.",
                color = cs.onSurface, fontSize = 15.sp)
        }
    }
}
