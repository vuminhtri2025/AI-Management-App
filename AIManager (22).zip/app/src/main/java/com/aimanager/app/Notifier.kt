package com.aimanager.app

import android.Manifest
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

/** Hẹn báo thức cho từng AI; khi hết thời gian hồi sẽ bắn thông báo (thường hoặc kiểu báo thức). */
object Notifier {
    const val ACTION = "com.aimanager.app.NOTIFY"
    const val CH = "cooldown"

    private fun pending(c: Context, id: String, name: String) = PendingIntent.getBroadcast(
        c, id.hashCode(),
        Intent(c, NotifyReceiver::class.java).setAction(ACTION).putExtra("id", id).putExtra("name", name),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Âm mặc định có thật: nếu máy chưa đặt nhạc báo thức thì lùi về nhạc thông báo / chuông. */
    private fun fallbackUri(c: Context, alarm: Boolean): Uri =
        (if (alarm) RingtoneManager.getActualDefaultRingtoneUri(c, RingtoneManager.TYPE_ALARM) else null)
            ?: RingtoneManager.getActualDefaultRingtoneUri(c, RingtoneManager.TYPE_NOTIFICATION)
            ?: RingtoneManager.getActualDefaultRingtoneUri(c, RingtoneManager.TYPE_RINGTONE)
            ?: Settings.System.DEFAULT_NOTIFICATION_URI

    /**
     * Âm của kênh không đổi được sau khi tạo, nên mỗi (kiểu báo thức, nhạc chuông) dùng một kênh riêng.
     * loud = true: phát bằng luồng âm lượng báo thức, kêu cả khi máy im lặng.
     */
    fun channelFor(c: Context, loud: Boolean, rt: String): String {
        val id = if (!loud && rt.isBlank()) CH else (if (loud) "a_" else "n_") + rt.hashCode()
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) != null) return id
        val ch = NotificationChannel(id, (if (loud) "Âm báo thức" else "Thông báo AI hồi xong") + if (rt.isNotBlank()) " (nhạc tùy chọn)" else "", NotificationManager.IMPORTANCE_HIGH)
        if (loud || rt.isNotBlank()) {
            val uri = if (rt.isNotBlank()) Uri.parse(rt) else fallbackUri(c, loud)
            val attrs = AudioAttributes.Builder()
                .setUsage(if (loud) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            ch.setSound(uri, attrs)
        }
        if (loud) {
            ch.description = "Kêu bằng âm lượng báo thức, kể cả khi điện thoại ở chế độ im lặng"
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 600, 300, 600, 300, 600)
            ch.setBypassDnd(true)
        }
        nm.createNotificationChannel(ch)
        return id
    }

    fun ensureChannels(c: Context) { channelFor(c, false, ""); channelFor(c, true, "") }

    /** Mở cài đặt thông báo của app để kiểm tra âm lượng, quyền phát âm thanh và "Đè lên Không làm phiền". */
    fun openLoudSettings(c: Context) {
        ensureChannels(c)
        c.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun sync(c: Context) {
        val sp = c.getSharedPreferences("data", 0)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val ais = loadAis(sp)
        val on = loadNotify(sp)
        val now = System.currentTimeMillis()
        val old = sp.getStringSet("n_ids", emptySet()) ?: emptySet()
        (old + ais.map { it.id }).forEach { am.cancel(pending(c, it, "")) }
        if (on) ais.filter { it.notify && it.cooldownUntil > now }.forEach {
            val pi = pending(c, it.id, it.name)
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.cooldownUntil, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.cooldownUntil, pi)
        }
        sp.edit().putStringSet("n_ids", ais.map { it.id }.toSet()).apply()
    }

    fun post(c: Context, ai: Ai) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        // Nhạc chuông lấy theo dự án Pending đầu tiên có đặt nhạc, rồi tới dự án bất kỳ có đặt nhạc
        val rt = (ai.projects.firstOrNull { it.status == 0 && it.ringtone.isNotBlank() } ?: ai.projects.firstOrNull { it.ringtone.isNotBlank() })?.ringtone ?: ""
        val nm = c.getSystemService(NotificationManager::class.java)
        val b = Notification.Builder(c, channelFor(c, ai.loud, rt))
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("${ai.name} đã sẵn sàng")
            .setContentText(if (ai.projects.isEmpty()) "AI đã hồi xong" else "${ai.projects.size} dự án · bấm để mở")
            .setContentIntent(openAiIntent(c, ai.id.hashCode(), ai.id)).setAutoCancel(true)
        if (ai.loud) b.setCategory(Notification.CATEGORY_ALARM).setTimeoutAfter(60_000)
        val n = b.build()
        if (ai.loud) n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(ai.id.hashCode(), n)
    }
}

class NotifyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            Intent.ACTION_BOOT_COMPLETED -> { Notifier.sync(c); AiWidget.refresh(c) }
            Notifier.ACTION -> {
                val sp = c.getSharedPreferences("data", 0)
                if (!loadNotify(sp)) return
                val ai = loadAis(sp).firstOrNull { it.id == i.getStringExtra("id") } ?: return
                if (!ai.notify) return
                if (ai.cooldownUntil > System.currentTimeMillis() + 5000) return
                Notifier.post(c, ai)
                AiWidget.refresh(c)
            }
        }
    }
}
