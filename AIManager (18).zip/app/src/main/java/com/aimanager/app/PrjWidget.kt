package com.aimanager.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.app.PendingIntent
import android.widget.RemoteViews
import android.widget.RemoteViewsService

/** Widget liệt kê các dự án đang ở trạng thái Waiting token (hồi token), cuộn được. */
class PrjWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = ids.forEach { draw(c, m, it) }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(ComponentName(c, PrjWidget::class.java)).forEach { draw(c, m, it) }
        }

        fun draw(c: Context, m: AppWidgetManager, id: Int) {
            val waiting = loadAis(c.getSharedPreferences("data", 0)).sumOf { a -> a.projects.count { it.status == 0 } }
            Tick.schedule(c)
            val rv = RemoteViews(c.packageName, R.layout.prj_widget)
            rv.setOnClickPendingIntent(R.id.p_header, openAiIntent(c, 90000 + id, null))
            rv.setTextViewText(R.id.p_count, "$waiting dự án")
            val svc = Intent(c, PrjListService::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            svc.data = Uri.parse(svc.toUri(Intent.URI_INTENT_SCHEME))
            rv.setRemoteAdapter(R.id.p_list, svc)
            rv.setEmptyView(R.id.p_list, R.id.p_empty)
            rv.setPendingIntentTemplate(R.id.p_list, PendingIntent.getActivity(c, 2,
                Intent(c, MainActivity::class.java), PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            m.updateAppWidget(id, rv)
            m.notifyAppWidgetViewDataChanged(id, R.id.p_list)
        }
    }
}

class PrjListService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    class Factory(private val c: Context) : RemoteViewsFactory {
        private var rows = emptyList<Pair<Ai, Project>>()
        override fun onCreate() {}
        override fun onDataSetChanged() {
            rows = loadAis(c.getSharedPreferences("data", 0)).flatMap { a -> a.projects.filter { it.status == 0 }.map { a to it } }
        }
        override fun onDestroy() {}
        override fun getCount() = rows.size
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = rows.getOrNull(position)?.second?.id.hashCode().toLong()
        override fun hasStableIds() = true

        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(c.packageName, R.layout.prj_item)
            val (a, p) = rows.getOrNull(position) ?: return rv
            val rest = left(a, System.currentTimeMillis())
            val ready = rest == 0L
            rv.setTextViewText(R.id.p_name, p.name)
            rv.setTextViewText(R.id.p_sub, "AI: ${a.name}")
            rv.setTextViewText(R.id.p_right, if (ready) "● Sẵn sàng" else "● Đang hồi")
            rv.setTextColor(R.id.p_right, Color.parseColor(if (ready) "#2ED47A" else "#FFB02E"))
            rv.setViewVisibility(R.id.p_time, if (ready) View.GONE else View.VISIBLE)
            if (!ready) rv.setTextViewText(R.id.p_time, fmt(rest))
            rv.setOnClickFillInIntent(R.id.p_item, Intent().putExtra("ai", a.id).putExtra("prj", p.id).setData(Uri.parse("aim://open/${a.id}/${p.id}")))
            return rv
        }
    }
}
