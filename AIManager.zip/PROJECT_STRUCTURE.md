# AIManager – Sơ đồ dự án (Kotlin + Jetpack Compose)

```
AIManager/
├── .github/workflows/build.yml      # Workflow: unzip + build APK
├── .gitignore
├── PROJECT_STRUCTURE.md
├── settings.gradle.kts
├── build.gradle.kts                 # AGP 8.5.2, Kotlin 2.0.20
├── gradle.properties
└── app/
    ├── build.gradle.kts             # minSdk 26, compileSdk 34, Compose BOM
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/{font (Inter),mipmap-anydpi-v26 (icon),values,layout/ai_widget.xml,drawable/widget_bg.xml,xml/ai_widget_info.xml}
        └── java/com/aimanager/app/
            ├── MainActivity.kt      # Điểm vào
            ├── Model.kt             # Ai, Project + ViewModel + lưu SharedPreferences
            ├── Theme.kt             # Bảng màu tương lai, sáng/tối
            ├── Drag.kt              # Kéo-thả sắp xếp
            ├── Ui.kt                # Trang chủ, chi tiết AI, cài đặt
            ├── AiWidget.kt          # Widget màn hình chính (RemoteViews + Chronometer đếm ngược)
            ├── AiListWidget.kt      # Widget danh sách tất cả AI
            ├── WidgetConfigActivity.kt  # Chọn AI khi thả widget
            └── Notifier.kt          # Thông báo khi AI hồi xong (AlarmManager + Receiver)
```

## Cách dùng trên GitHub
1. Zip toàn bộ thư mục dự án (file `AIManager.zip`), đẩy lên repo (nhánh main).
2. Tạo file `.github/workflows/build.yml` ở gốc repo (hoặc để nguyên trong zip và tải thêm 1 bản ra ngoài).
3. Actions → Build APK → tải artifact `AIManager-debug-apk`.

LƯU Ý: GitHub chỉ đọc workflow ở `.github/workflows/` ngoài gốc repo, KHÔNG đọc bên trong file zip.
