package com.aimanager.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/** Hẹn làm mới widget đúng lúc số phút hiển thị đổi (hoặc lúc AI hồi xong). */
object Tick {
    fun schedule(c: Context) {
        val now = System.currentTimeMillis()
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(c, 7777, Intent(c, AiListWidget::class.java).setAction(AiListWidget.ACTION),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val next = loadAis(c.getSharedPreferences("data", 0)).filter { it.cooldownUntil > now }.minOfOrNull {
            val rem = it.cooldownUntil - now
            it.cooldownUntil - ((rem + 59_999) / 60_000 - 1) * 60_000 + 300
        }
        if (next == null) { am.cancel(pi); return }
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExact(AlarmManager.RTC, next, pi)
        else am.set(AlarmManager.RTC, next, pi)
    }
}
