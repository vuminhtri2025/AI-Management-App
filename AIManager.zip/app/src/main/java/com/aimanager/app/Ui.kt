package com.aimanager.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import java.time.*

private val cs @Composable get() = MaterialTheme.colorScheme
private val line @Composable get() = cs.onSurface.copy(alpha = .1f)
private val tnum = TextStyle(fontFeatureSettings = "tnum")

@Composable
fun Root(vm: AppVM) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { val t = System.currentTimeMillis(); now = t; delay(1000 - t % 1000) } }
    var screen by rememberSaveable { mutableStateOf("home") }
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val ask: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { if (vm.notify) ask() }
    BackHandler(screen != "home") { screen = "home" }
    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        when (screen) {
            "home" -> Home(vm, now, { screen = it }, { screen = "settings" })
            "settings" -> SettingsScreen(vm, ask) { screen = "home" }
            else -> {
                val ai = vm.ais.firstOrNull { it.id == screen }
                if (ai == null) screen = "home" else Detail(vm, ai, now) { screen = "home" }
            }
        }
    }
}

// ---------- thành phần dùng chung ----------

@Composable
fun Dots(tint: Color) = androidx.compose.foundation.Canvas(Modifier.size(18.dp, 26.dp)) {
    val r = 2.4.dp.toPx()
    for (x in 0..1) for (y in 0..2) drawCircle(tint, r, Offset(size.width * (.25f + .5f * x), size.height * (.15f + .35f * y)))
}

@Composable
fun Pill(ready: Boolean, big: Boolean = false) {
    val c = if (ready) Ready else Wait
    Row(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .16f)).padding(horizontal = if (big) 18.dp else 14.dp, vertical = if (big) 10.dp else 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(c, CircleShape)); Spacer(Modifier.width(8.dp))
        Text(if (ready) "Sẵn sàng" else "Đang hồi", color = c, fontWeight = FontWeight.SemiBold, fontSize = if (big) 17.sp else 15.sp)
    }
}

@Composable
fun Chip(text: String, main: Boolean) =
    Text((if (main) "★ " else "") + text, color = cs.primary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(cs.primary.copy(alpha = if (main) .22f else .12f)).padding(horizontal = 14.dp, vertical = 7.dp))

@Composable
fun BigButton(text: String, onClick: () -> Unit) =
    Button(onClick, Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(29.dp),
        colors = ButtonDefaults.buttonColors(containerColor = cs.primary, contentColor = cs.onPrimary)) {
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }

@Composable
fun Segmented(opts: List<String>, sel: Int, on: (Int) -> Unit) =
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surface).padding(6.dp)) {
        opts.forEachIndexed { i, t ->
            Box(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(if (sel == i) cs.surfaceVariant else Color.Transparent)
                .clickable { on(i) }.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                Text(t, color = if (sel == i) cs.onSurface else cs.onSurfaceVariant, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
    }

@Composable
fun TopBar(title: String, back: () -> Unit, trailing: @Composable () -> Unit = {}) =
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(back) { Icon(Icons.Default.ArrowBack, null, tint = cs.onSurface) }
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, modifier = Modifier.weight(1f), maxLines = 1)
        trailing()
    }

// ---------- trang chủ ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Home(vm: AppVM, now: Long, open: (String) -> Unit, settings: () -> Unit) {
    val ls = rememberLazyListState()
    val drag = remember { DragCtl(ls, 2) { a, b -> vm.moveAi(a, b) } }
    var addAi by remember { mutableStateOf(false) }
    val active = vm.ais.sumOf { it.projects.size }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(state = ls, modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item(key = "h") {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text("AI Manager", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, letterSpacing = (-0.5).sp)
                        Text("${vm.ais.size} AI · $active dự án đang hoạt động", fontSize = 16.sp, color = cs.onSurfaceVariant)
                    }
                    IconButton(settings) { Icon(Icons.Default.Settings, null, tint = cs.onSurfaceVariant) }
                }
            }
            item(key = "hint") {
                Text(if (vm.ais.isEmpty()) "Chưa có AI nào. Bấm \"Thêm AI\" để bắt đầu." else "Giữ và kéo cụm chấm bên trái để sắp xếp lại thứ tự",
                    fontSize = 14.sp, color = cs.onSurfaceVariant)
            }
            itemsIndexed(vm.ais, key = { _, a -> a.id }) { i, a -> AiCard(a, i, now, drag) { open(a.id) } }
        }
        Box(Modifier.padding(20.dp, 8.dp, 20.dp, 16.dp)) { BigButton("+  Thêm AI") { addAi = true } }
    }
    if (addAi) TextDialog("Thêm AI", "Tên AI", { addAi = false }) { vm.addAi(it); addAi = false }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiCard(a: Ai, i: Int, now: Long, drag: DragCtl, onClick: () -> Unit) {
    val ready = left(a, now) == 0L
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.fillMaxWidth().zIndex(if (drag.dragging == i) 1f else 0f)
            .graphicsLayer { translationY = if (drag.dragging == i) drag.dy else 0f }
            .clip(shape).background(cs.surface).border(1.dp, line, shape)
            .clickable(onClick = onClick).padding(start = 6.dp, end = 18.dp, top = 18.dp, bottom = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp, 56.dp).dragHandle(a.id, i, drag), contentAlignment = Alignment.Center) { Dots(cs.onSurfaceVariant.copy(alpha = .8f)) }
        Column(Modifier.weight(1f)) {
            Text(a.name, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1)
            if (a.projects.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    a.projects.forEachIndexed { j, p -> Chip(p.name, j == 0) }
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(horizontalAlignment = Alignment.End) {
            Pill(ready)
            if (!ready) Text(fmt(left(a, now)), style = tnum, fontSize = 16.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp, end = 4.dp))
        }
    }
}

// ---------- hộp thoại ----------

@Composable
fun TextDialog(title: String, hint: String, close: () -> Unit, ok: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(26.dp), containerColor = cs.surface, title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { OutlinedTextField(t, { t = it }, label = { Text(hint) }, singleLine = true, shape = RoundedCornerShape(16.dp)) },
        confirmButton = { TextButton({ if (t.isNotBlank()) ok(t.trim()) }) { Text("OK", fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(close) { Text("Hủy") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CooldownPicker(onDone: (Long) -> Unit, close: () -> Unit) {
    var date by remember { mutableStateOf<LocalDate?>(null) }
    if (date == null) {
        val st = rememberDatePickerState(initialSelectedDateMillis = System.currentTimeMillis())
        DatePickerDialog(onDismissRequest = close,
            confirmButton = {
                TextButton({ st.selectedDateMillis?.let { date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() } }) { Text("Tiếp") }
            },
            dismissButton = { TextButton(close) { Text("Hủy") } }) { DatePicker(st) }
    } else {
        val n = LocalTime.now()
        val ts = rememberTimePickerState(n.hour, n.minute, true)
        AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(26.dp), containerColor = cs.surface, title = { Text("Giờ hồi chính xác", fontWeight = FontWeight.Bold) },
            text = { TimePicker(ts) },
            confirmButton = {
                TextButton({
                    onDone(LocalDateTime.of(date!!, LocalTime.of(ts.hour, ts.minute)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())
                }) { Text("Đặt") }
            },
            dismissButton = { TextButton(close) { Text("Hủy") } })
    }
}

// ---------- chi tiết AI ----------

@Composable
fun Detail(vm: AppVM, a: Ai, now: Long, back: () -> Unit) {
    val ls = rememberLazyListState()
    val drag = remember(a.id) { DragCtl(ls, 3) { x, y -> vm.movePrj(a.id, x, y) } }
    var pick by remember { mutableStateOf(false) }
    var add by remember { mutableStateOf(false) }
    val ready = left(a, now) == 0L
    val col = if (ready) Ready else Wait
    Column(Modifier.fillMaxSize()) {
        LazyColumn(state = ls, modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item(key = "bar") {
                TopBar(a.name, back) { IconButton({ vm.delAi(a.id); back() }) { Icon(Icons.Default.Delete, null, tint = cs.onSurfaceVariant) } }
            }
            item(key = "st") {
                val shape = RoundedCornerShape(26.dp)
                Column(Modifier.fillMaxWidth().clip(shape).background(cs.surface).border(1.dp, line, shape).padding(20.dp)) {
                    Pill(ready, big = true)
                    if (!ready) {
                        Text(fmt(left(a, now)), style = tnum, color = col, fontSize = 46.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                        val t = Instant.ofEpochMilli(a.cooldownUntil).atZone(ZoneId.systemDefault())
                        Text("Hồi lúc %02d:%02d · %02d/%02d/%d".format(t.hour, t.minute, t.dayOfMonth, t.monthValue, t.year), color = cs.onSurfaceVariant, fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button({ pick = true }, shape = RoundedCornerShape(18.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = cs.primary, contentColor = cs.onPrimary)) { Text("Chọn giờ hồi", fontWeight = FontWeight.SemiBold) }
                        if (!ready) OutlinedButton({ vm.setCd(a.id, 0) }, shape = RoundedCornerShape(18.dp)) { Text("Đặt sẵn sàng", fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
            item(key = "pt") {
                Text("Dự án · kéo để sắp xếp, ★ là dự án chính", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
            }
            itemsIndexed(a.projects, key = { _, p -> p.id }) { i, p ->
                val shape = RoundedCornerShape(22.dp)
                Row(
                    Modifier.fillMaxWidth().zIndex(if (drag.dragging == i) 1f else 0f)
                        .graphicsLayer { translationY = if (drag.dragging == i) drag.dy else 0f }
                        .clip(shape).background(cs.surface).border(1.dp, if (i == 0) cs.primary.copy(alpha = .5f) else line, shape)
                        .padding(start = 6.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(40.dp, 48.dp).dragHandle(p.id, i, drag), contentAlignment = Alignment.Center) { Dots(cs.onSurfaceVariant.copy(alpha = .8f)) }
                    Text(if (i == 0) "★" else "${i + 1}", color = if (i == 0) cs.primary else cs.onSurfaceVariant, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                    Text(p.name, color = cs.onSurface, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    IconButton({ vm.delPrj(a.id, p.id) }) { Icon(Icons.Default.Close, null, tint = cs.onSurfaceVariant) }
                }
            }
        }
        Box(Modifier.padding(20.dp, 8.dp, 20.dp, 16.dp)) { BigButton("+  Thêm dự án") { add = true } }
    }
    if (pick) CooldownPicker({ vm.setCd(a.id, it); pick = false }) { pick = false }
    if (add) TextDialog("Thêm dự án", "Tên dự án", { add = false }) { vm.addPrj(a.id, it); add = false }
}

// ---------- cài đặt ----------

@Composable
fun SettingsScreen(vm: AppVM, ask: () -> Unit, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TopBar("Cài đặt", back)
        Column(Modifier.padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Giao diện", color = cs.onSurfaceVariant, fontSize = 14.sp)
            Segmented(listOf("Tự động", "Sáng", "Tối"), vm.mode) { vm.changeMode(it) }
            Text("Màu chủ đạo", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                palettes.forEachIndexed { i, p ->
                    Box(Modifier.size(52.dp).clip(CircleShape).background(Color(p.second))
                        .border(if (vm.pal == i) 3.dp else 0.dp, cs.onSurface, CircleShape).clickable { vm.changePal(i) })
                }
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Thông báo khi AI hồi xong", color = cs.onSurface, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Switch(vm.notify, { vm.changeNotify(it); if (it) ask() })
            }
            Text("Widget", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Text("Giữ lâu màn hình chính → Widget → AI Manager. Có 2 loại: \"Một AI\" và \"Tất cả AI\" (danh sách). Kéo giãn widget để đổi kích thước.",
                color = cs.onSurface, fontSize = 15.sp)
        }
    }
}
