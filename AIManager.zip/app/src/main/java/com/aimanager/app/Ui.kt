package com.aimanager.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import java.time.*

private val cs @Composable get() = MaterialTheme.colorScheme

@Composable
fun Root(vm: AppVM) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { val t = System.currentTimeMillis(); now = t; delay(1000 - t % 1000) } }
    var screen by rememberSaveable { mutableStateOf("home") }
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val ask: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { if (vm.notify) ask() }
    BackHandler(screen != "home") { screen = "home" }
    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        when (screen) {
            "home" -> Home(vm, now, { screen = it }, { screen = "settings" })
            "settings" -> SettingsScreen(vm, ask) { screen = "home" }
            else -> {
                val ai = vm.ais.firstOrNull { it.id == screen }
                if (ai == null) screen = "home" else Detail(vm, ai, now) { screen = "home" }
            }
        }
    }
}

@Composable
fun Chip(text: String, main: Boolean) {
    val c = if (main) cs.primary else cs.onSurfaceVariant
    Text((if (main) "★ " else "") + text, color = c, fontSize = 12.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .12f)).padding(horizontal = 10.dp, vertical = 4.dp))
}

@Composable
fun Title(text: String, trailing: @Composable RowScope.() -> Unit = {}) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(text.uppercase(), color = cs.onSurfaceVariant, fontSize = 12.sp, letterSpacing = 3.sp, modifier = Modifier.weight(1f))
        trailing()
    }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Home(vm: AppVM, now: Long, open: (String) -> Unit, settings: () -> Unit) {
    val ls = rememberLazyListState()
    val drag = remember { DragCtl(ls, 2) { a, b -> vm.moveAi(a, b) } }
    var addAi by remember { mutableStateOf(false) }
    val active = vm.ais.sumOf { it.projects.size }
    LazyColumn(state = ls, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxSize()) {
        item(key = "h") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("AI MANAGER", fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp,
                        style = androidx.compose.ui.text.TextStyle(brush = Brush.horizontalGradient(listOf(cs.primary, cs.secondary))))
                    Text("${vm.ais.size} AI · $active dự án đang hoạt động", color = cs.onSurfaceVariant, fontSize = 13.sp)
                }
                IconButton(settings) { Icon(Icons.Default.Settings, null, tint = cs.onSurfaceVariant) }
            }
        }
        item(key = "t") { Title("Danh sách AI") { IconButton({ addAi = true }) { Icon(Icons.Default.Add, null, tint = cs.primary) } } }
        itemsIndexed(vm.ais, key = { _, a -> a.id }) { i, a -> AiCard(a, i, now, drag) { open(a.id) } }
    }
    if (addAi) TextDialog("Thêm AI", "Tên AI", { addAi = false }) { vm.addAi(it); addAi = false }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiCard(a: Ai, i: Int, now: Long, drag: DragCtl, onClick: () -> Unit) {
    val ready = left(a, now) == 0L
    val col = if (ready) Ready else Wait
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().zIndex(if (drag.dragging == i) 1f else 0f)
            .graphicsLayer { translationY = if (drag.dragging == i) drag.dy else 0f }
            .clip(shape).background(cs.surface)
            .border(1.dp, Brush.linearGradient(listOf(col.copy(.7f), Color.Transparent)), shape)
            .clickable(onClick = onClick).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(col, CircleShape))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(a.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
                Text(if (ready) "Sẵn sàng" else "Chờ hồi · " + fmt(left(a, now)), color = col, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            }
            Icon(Icons.Default.Menu, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(36.dp).padding(6.dp).dragHandle(a.id, i, drag))
        }
        if (a.projects.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                a.projects.forEachIndexed { j, p -> Chip(p.name, j == 0) }
            }
        }
    }
}

@Composable
fun TextDialog(title: String, hint: String, close: () -> Unit, ok: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, label = { Text(hint) }, singleLine = true) },
        confirmButton = { TextButton({ if (t.isNotBlank()) ok(t.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(close) { Text("Hủy") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CooldownPicker(onDone: (Long) -> Unit, close: () -> Unit) {
    var date by remember { mutableStateOf<LocalDate?>(null) }
    if (date == null) {
        val st = rememberDatePickerState(initialSelectedDateMillis = System.currentTimeMillis())
        DatePickerDialog(onDismissRequest = close,
            confirmButton = {
                TextButton({ st.selectedDateMillis?.let { date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() } }) { Text("Tiếp") }
            },
            dismissButton = { TextButton(close) { Text("Hủy") } }) { DatePicker(st) }
    } else {
        val n = LocalTime.now()
        val ts = rememberTimePickerState(n.hour, n.minute, true)
        AlertDialog(onDismissRequest = close, title = { Text("Giờ hồi chính xác") },
            text = { TimePicker(ts) },
            confirmButton = {
                TextButton({
                    onDone(LocalDateTime.of(date!!, LocalTime.of(ts.hour, ts.minute)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())
                }) { Text("Đặt") }
            },
            dismissButton = { TextButton(close) { Text("Hủy") } })
    }
}

@Composable
fun Detail(vm: AppVM, a: Ai, now: Long, back: () -> Unit) {
    val ls = rememberLazyListState()
    val drag = remember(a.id) { DragCtl(ls, 3) { x, y -> vm.movePrj(a.id, x, y) } }
    var pick by remember { mutableStateOf(false) }
    var add by remember { mutableStateOf(false) }
    val ready = left(a, now) == 0L
    val col = if (ready) Ready else Wait
    LazyColumn(state = ls, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
        item(key = "bar") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(back) { Icon(Icons.Default.ArrowBack, null, tint = cs.onSurface) }
                Text(a.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), color = cs.onSurface)
                IconButton({ vm.delAi(a.id); back() }) { Icon(Icons.Default.Delete, null, tint = cs.onSurfaceVariant) }
            }
        }
        item(key = "st") {
            val shape = RoundedCornerShape(24.dp)
            Column(Modifier.fillMaxWidth().clip(shape).background(Brush.linearGradient(listOf(col.copy(.2f), cs.surface))).border(1.dp, col.copy(.4f), shape).padding(20.dp)) {
                Text(if (ready) "SẴN SÀNG" else "ĐANG CHỜ HỒI", color = col, letterSpacing = 3.sp, fontSize = 12.sp)
                if (!ready) {
                    Text(fmt(left(a, now)), color = col, fontSize = 44.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    val t = Instant.ofEpochMilli(a.cooldownUntil).atZone(ZoneId.systemDefault())
                    Text("Hồi lúc %02d:%02d · %02d/%02d/%d".format(t.hour, t.minute, t.dayOfMonth, t.monthValue, t.year), color = cs.onSurfaceVariant, fontSize = 13.sp)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ pick = true }) { Text("Chọn giờ hồi") }
                    if (!ready) OutlinedButton({ vm.setCd(a.id, 0) }) { Text("Sẵn sàng") }
                }
            }
        }
        item(key = "pt") { Title("Dự án (★ = chính)") { IconButton({ add = true }) { Icon(Icons.Default.Add, null, tint = cs.primary) } } }
        itemsIndexed(a.projects, key = { _, p -> p.id }) { i, p ->
            Row(
                Modifier.fillMaxWidth().zIndex(if (drag.dragging == i) 1f else 0f)
                    .graphicsLayer { translationY = if (drag.dragging == i) drag.dy else 0f }
                    .clip(RoundedCornerShape(16.dp)).background(if (i == 0) cs.primary.copy(.12f) else cs.surface).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (i == 0) "★" else "${i + 1}", color = if (i == 0) cs.primary else cs.onSurfaceVariant, modifier = Modifier.width(26.dp))
                Text(p.name, color = cs.onSurface, modifier = Modifier.weight(1f))
                IconButton({ vm.delPrj(a.id, p.id) }) { Icon(Icons.Default.Close, null, tint = cs.onSurfaceVariant) }
                Icon(Icons.Default.Menu, null, tint = cs.onSurfaceVariant, modifier = Modifier.size(36.dp).padding(6.dp).dragHandle(p.id, i, drag))
            }
        }
    }
    if (pick) CooldownPicker({ vm.setCd(a.id, it); pick = false }) { pick = false }
    if (add) TextDialog("Thêm dự án", "Tên dự án", { add = false }) { vm.addPrj(a.id, it); add = false }
}

@Composable
fun SettingsScreen(vm: AppVM, ask: () -> Unit, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Default.ArrowBack, null, tint = cs.onSurface) }
            Text("Giao diện", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
        }
        Title("Màu chủ đạo")
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            palettes.forEachIndexed { i, p ->
                Box(Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(p.second), Color(p.third))))
                    .border(if (vm.pal == i) 3.dp else 0.dp, cs.onSurface, CircleShape).clickable { vm.changePal(i) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Chế độ tối", color = cs.onSurface, modifier = Modifier.weight(1f))
            Switch(vm.dark, { vm.changeDark(it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Thông báo khi AI hồi xong", color = cs.onSurface, modifier = Modifier.weight(1f))
            Switch(vm.notify, { vm.changeNotify(it); if (it) ask() })
        }
        Title("Widget màn hình chính")
        Text("Giữ lâu màn hình chính → Widget → AI Manager → thả ra và chọn AI. Kéo giãn widget để đổi kích thước.", color = cs.onSurfaceVariant, fontSize = 13.sp)
    }
}
