package com.aimanager.app

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Hiện khi người dùng thả widget ra màn hình chính: chọn AI cho widget đó. */
class WidgetConfigActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        val sp = getSharedPreferences("data", 0)
        val ais = loadAis(sp)
        setContent {
            AppTheme(loadPal(sp), true) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(Modifier.systemBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Chọn AI cho widget", style = MaterialTheme.typography.titleLarge)
                        if (ais.isEmpty()) Text("Hãy mở ứng dụng và thêm AI trước.")
                        ais.forEach { a ->
                            Button({
                                sp.edit().putString("w_$id", a.id).apply()
                                AiWidget.draw(this@WidgetConfigActivity, AppWidgetManager.getInstance(this@WidgetConfigActivity), id)
                                setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
                                finish()
                            }, Modifier.fillMaxWidth()) { Text(a.name) }
                        }
                    }
                }
            }
        }
    }
}
