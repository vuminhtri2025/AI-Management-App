package com.aimanager.app

import android.Manifest
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Hẹn báo thức cho từng AI; khi hết thời gian hồi sẽ bắn thông báo. */
object Notifier {
    const val ACTION = "com.aimanager.app.NOTIFY"
    private const val CH = "cooldown"

    private fun pending(c: Context, id: String, name: String) = PendingIntent.getBroadcast(
        c, id.hashCode(),
        Intent(c, NotifyReceiver::class.java).setAction(ACTION).putExtra("id", id).putExtra("name", name),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun sync(c: Context) {
        val sp = c.getSharedPreferences("data", 0)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val ais = loadAis(sp)
        val on = loadNotify(sp)
        val now = System.currentTimeMillis()
        val old = sp.getStringSet("n_ids", emptySet()) ?: emptySet()
        (old + ais.map { it.id }).forEach { am.cancel(pending(c, it, "")) }
        if (on) ais.filter { it.cooldownUntil > now }.forEach {
            val pi = pending(c, it.id, it.name)
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.cooldownUntil, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.cooldownUntil, pi)
        }
        sp.edit().putStringSet("n_ids", ais.map { it.id }.toSet()).apply()
    }

    fun post(c: Context, ai: Ai) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "AI hồi xong", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("${ai.name} đã sẵn sàng")
            .setContentText(if (ai.projects.isEmpty()) "AI đã hồi xong" else "${ai.projects.size} dự án đang chờ · ★ ${ai.projects.first().name}")
            .setContentIntent(open).setAutoCancel(true).build()
        nm.notify(ai.id.hashCode(), n)
    }
}

class NotifyReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            Intent.ACTION_BOOT_COMPLETED -> { Notifier.sync(c); AiWidget.refresh(c) }
            Notifier.ACTION -> {
                val sp = c.getSharedPreferences("data", 0)
                if (!loadNotify(sp)) return
                val ai = loadAis(sp).firstOrNull { it.id == i.getStringExtra("id") } ?: return
                if (ai.cooldownUntil > System.currentTimeMillis() + 5000) return
                Notifier.post(c, ai)
                AiWidget.refresh(c)
            }
        }
    }
}
