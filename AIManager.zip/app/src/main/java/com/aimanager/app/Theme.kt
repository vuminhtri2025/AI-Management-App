package com.aimanager.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val palettes = listOf(
    Triple("Cyan", 0xFF00E5FF, 0xFF7C4DFF),
    Triple("Magenta", 0xFFFF4DDB, 0xFF7C4DFF),
    Triple("Lime", 0xFFB2FF59, 0xFF00E5FF),
    Triple("Amber", 0xFFFFB300, 0xFFFF5252),
)
val Ready = Color(0xFF00E676)
val Wait = Color(0xFFFFB74D)

@Composable
fun AppTheme(pal: Int, dark: Boolean, content: @Composable () -> Unit) {
    val p = palettes[pal.coerceIn(0, palettes.lastIndex)]
    val scheme = if (dark) darkColorScheme(
        primary = Color(p.second), secondary = Color(p.third),
        background = Color(0xFF06080D), surface = Color(0xFF0E131D), surfaceVariant = Color(0xFF1A2232),
        onSurface = Color(0xFFE8EEF8), onSurfaceVariant = Color(0xFF8A96AB), onPrimary = Color.Black
    ) else lightColorScheme(
        primary = Color(p.second).copy(alpha = 1f), secondary = Color(p.third),
        background = Color(0xFFF2F5FA), surface = Color.White, surfaceVariant = Color(0xFFE6EBF3),
        onSurface = Color(0xFF0B1020), onSurfaceVariant = Color(0xFF5B677C), onPrimary = Color.Black
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
