package com.aimanager.app

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput

/** Kéo-thả sắp xếp trong LazyColumn. base = số item đứng trước danh sách có thể kéo. */
class DragCtl(private val st: LazyListState, private val base: Int, private val onMove: (Int, Int) -> Unit) {
    var dragging by mutableIntStateOf(-1); private set
    var dy by mutableFloatStateOf(0f); private set
    fun start(i: Int) { dragging = i; dy = 0f }
    fun end() { dragging = -1; dy = 0f }
    fun delta(d: Float) {
        if (dragging < 0) return
        dy += d
        val items = st.layoutInfo.visibleItemsInfo
        val cur = items.firstOrNull { it.index == dragging + base } ?: return
        val c = cur.offset + cur.size / 2f + dy
        val t = items.firstOrNull { it.index >= base && it.index != cur.index && c > it.offset && c < it.offset + it.size } ?: return
        val newOff = if (t.index < cur.index) t.offset else t.offset + t.size - cur.size
        dy -= (newOff - cur.offset)
        val to = t.index - base
        onMove(dragging, to); dragging = to
    }
}

@Composable
fun Modifier.dragHandle(key: Any, index: Int, ctl: DragCtl): Modifier {
    val cur by rememberUpdatedState(index)
    return pointerInput(key) {
        detectDragGestures(
            onDragStart = { ctl.start(cur) },
            onDrag = { c, d -> c.consume(); ctl.delta(d.y) },
            onDragEnd = { ctl.end() }, onDragCancel = { ctl.end() }
        )
    }
}
