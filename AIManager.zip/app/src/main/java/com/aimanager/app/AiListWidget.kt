package com.aimanager.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

/** Widget danh sách: hiển thị tất cả AI cùng trạng thái, đếm ngược. Kéo giãn để hiện thêm dòng. */
class AiListWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) = ids.forEach { draw(c, m, it) }
    override fun onAppWidgetOptionsChanged(c: Context, m: AppWidgetManager, id: Int, o: android.os.Bundle) = draw(c, m, id)
    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == ACTION) AiWidget.refresh(c)
    }

    companion object {
        const val ACTION = "com.aimanager.app.REFRESH_LIST"
        private const val MAX = 10

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            m.getAppWidgetIds(ComponentName(c, AiListWidget::class.java)).forEach { draw(c, m, it) }
        }

        private fun rid(c: Context, i: Int, s: String) = c.resources.getIdentifier("r${i}_$s", "id", c.packageName)

        fun draw(c: Context, m: AppWidgetManager, id: Int) {
            val ais = loadAis(c.getSharedPreferences("data", 0))
            val h = m.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 200)
            val fit = ((h - 60) / 56).coerceIn(1, MAX)
            val now = System.currentTimeMillis()
            val rv = RemoteViews(c.packageName, R.layout.ai_list_widget)
            rv.setOnClickPendingIntent(R.id.l_root, PendingIntent.getActivity(c, 0,
                Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            rv.setTextViewText(R.id.l_count, "${ais.size} AI")
            for (i in 0 until MAX) {
                val ai = ais.getOrNull(i)?.takeIf { i < fit }
                rv.setViewVisibility(c.resources.getIdentifier("r$i", "id", c.packageName), if (ai == null) View.GONE else View.VISIBLE)
                if (ai == null) continue
                val rest = left(ai, now)
                val ready = rest == 0L
                val col = if (ready) Color.parseColor("#2ED47A") else Color.parseColor("#FFB02E")
                rv.setTextViewText(rid(c, i, "name"), ai.name)
                rv.setTextViewText(rid(c, i, "sub"), if (ai.projects.isEmpty()) "Chưa có dự án" else ai.projects.joinToString(" · ") { it.name })
                rv.setTextViewText(rid(c, i, "status"), if (ready) "● Sẵn sàng" else "● Đang hồi")
                rv.setTextColor(rid(c, i, "status"), col)
                val t = rid(c, i, "time")
                rv.setViewVisibility(t, if (ready) View.GONE else View.VISIBLE)
                if (!ready) rv.setTextViewText(t, fmt(rest))
            }
            Tick.schedule(c)
            m.updateAppWidget(id, rv)
        }
    }
}
