package com.aimanager.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import android.widget.Toast
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.*

private val cs @Composable get() = MaterialTheme.colorScheme
private val line @Composable get() = cs.onSurface.copy(alpha = .14f)
private val tnum = TextStyle(fontFeatureSettings = "tnum")

@Composable
fun Root(vm: AppVM, target: String?, consumed: () -> Unit) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(vm.ais) { while (true) { val t = System.currentTimeMillis(); now = t; delay(nextTickDelay(vm.ais, t)) } }
    // Ngăn xếp điều hướng, ví dụ "home|p:ai:prj": nút quay lại luôn về đúng màn hình trước đó
    var nav by rememberSaveable { mutableStateOf("home") }
    val screen = nav.substringAfterLast("|")
    fun push(s: String) { nav = "$nav|$s" }
    fun pop() { nav = if (nav.contains('|')) nav.substringBeforeLast("|") else "home" }
    LaunchedEffect(target) {
        if (target != null) {
            val ok = if (target.startsWith("p:")) {
                val pp = target.split(":")
                vm.ais.any { a -> a.id == pp.getOrNull(1) && a.projects.any { it.id == pp.getOrNull(2) } }
            } else vm.ais.any { it.id == target }
            if (ok) nav = "home|$target"
            consumed()
        }
    }
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val ask: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { if (vm.notify) ask() }
    BackHandler(nav.contains('|')) { pop() }
    val holder = rememberSaveableStateHolder()
    Box(Modifier.fillMaxSize().background(cs.background).systemBarsPadding()) {
        holder.SaveableStateProvider(screen) {
            when (screen) {
                "home" -> Home(vm, now, { push(it) }, { a, p -> push("p:$a:$p") }, { push("settings") })
                "settings" -> SettingsScreen(vm, ask) { pop() }
                else -> if (screen.startsWith("p:")) {
                    val parts = screen.split(":")
                    val ai = vm.ais.firstOrNull { it.id == parts[1] }
                    val p = ai?.projects?.firstOrNull { it.id == parts[2] }
                    if (ai == null || p == null) { nav = "home" } else { ProjectScreen(vm, ai, p) { pop() } }
                } else {
                    val ai = vm.ais.firstOrNull { it.id == screen }
                    if (ai == null) { nav = "home" } else { Detail(vm, ai, now, { push("p:${ai.id}:$it") }) { pop() } }
                }
            }
        }
    }
}

// ---------- thành phần dùng chung ----------

@Composable
fun Dots(tint: Color) = androidx.compose.foundation.Canvas(Modifier.size(18.dp, 26.dp)) {
    val r = 2.4.dp.toPx()
    for (x in 0..1) for (y in 0..2) drawCircle(tint, r, Offset(size.width * (.25f + .5f * x), size.height * (.15f + .35f * y)))
}

@Composable
fun ClockIcon(tint: Color, dp: androidx.compose.ui.unit.Dp = 24.dp) = androidx.compose.foundation.Canvas(Modifier.size(dp)) {
    val w = size.minDimension
    val sw = w * .09f
    drawCircle(tint, radius = w / 2 - sw, style = androidx.compose.ui.graphics.drawscope.Stroke(sw))
    drawLine(tint, Offset(w / 2, w / 2), Offset(w / 2, w * .27f), sw, androidx.compose.ui.graphics.StrokeCap.Round)
    drawLine(tint, Offset(w / 2, w / 2), Offset(w * .68f, w * .6f), sw, androidx.compose.ui.graphics.StrokeCap.Round)
}

@Composable
fun FolderIcon(tint: Color, dp: androidx.compose.ui.unit.Dp = 24.dp) = androidx.compose.foundation.Canvas(Modifier.size(dp)) {
    val w = size.minDimension
    val sw = w * .09f
    val path = androidx.compose.ui.graphics.Path().apply {
        moveTo(w * .08f, w * .22f); lineTo(w * .38f, w * .22f); lineTo(w * .48f, w * .34f); lineTo(w * .92f, w * .34f)
        lineTo(w * .92f, w * .82f); lineTo(w * .08f, w * .82f); close()
    }
    drawPath(path, tint, style = androidx.compose.ui.graphics.drawscope.Stroke(sw, join = androidx.compose.ui.graphics.StrokeJoin.Round))
}

@Composable
fun ProgressBar(frac: Float, color: Color) =
    Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(cs.surfaceVariant)) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color, RoundedCornerShape(50)))
    }

@Composable
fun RowScope.TileButton(text: String, enabled: Boolean = true, onClick: () -> Unit, icon: @Composable () -> Unit) =
    Column(Modifier.weight(1f).graphicsLayer { alpha = if (enabled) 1f else .4f }.clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant)
        .clickable(enabled = enabled, onClick = onClick).padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        icon()
        Spacer(Modifier.height(8.dp))
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
    }

@Composable
fun Pill(ready: Boolean, big: Boolean = false) {
    val c = if (ready) Ready else Wait
    Row(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .16f)).padding(horizontal = if (big) 14.dp else 10.dp, vertical = if (big) 8.dp else 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(c, CircleShape)); Spacer(Modifier.width(8.dp))
        Text(if (ready) "Sẵn sàng" else "Đang hồi", color = c, fontWeight = FontWeight.SemiBold, fontSize = if (big) 15.sp else 13.sp)
    }
}

@Composable
fun Chip(text: String, status: Int, main: Boolean) {
    val c = StatusCol[status]
    Text((if (main) "★ " else "") + text, color = c, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        textDecoration = if (status == 2) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = if (main) .22f else .12f)).padding(horizontal = 12.dp, vertical = 5.dp))
}

@Composable
fun StatusPill(status: Int) {
    val c = StatusCol[status]
    Row(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .16f)).padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(c, CircleShape)); Spacer(Modifier.width(6.dp))
        Text(StatusName[status], color = c, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun BigButton(text: String, onClick: () -> Unit) =
    Button(onClick, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp),
        colors = ButtonDefaults.buttonColors(containerColor = cs.onSurface, contentColor = cs.background)) {
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }

@Composable
fun Segmented(opts: List<String>, sel: Int, on: (Int) -> Unit) =
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surface).padding(6.dp)) {
        opts.forEachIndexed { i, t ->
            Box(Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(if (sel == i) cs.surfaceVariant else Color.Transparent)
                .clickable { on(i) }.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                Text(t, color = if (sel == i) cs.onSurface else cs.onSurfaceVariant, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
    }

@Composable
fun MoreMenu(onRename: () -> Unit, onDelete: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }, Modifier.size(36.dp)) { Icon(Icons.Default.MoreVert, "Tùy chọn", tint = cs.onSurfaceVariant) }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem(text = { Text("Đổi tên") }, onClick = { open = false; onRename() })
            DropdownMenuItem(text = { Text("Xóa", color = StatusCol[0], fontWeight = FontWeight.SemiBold) }, onClick = { open = false; onDelete() })
        }
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, onOk: () -> Unit, onClose: () -> Unit) =
    AlertDialog(onDismissRequest = onClose, shape = RoundedCornerShape(26.dp), containerColor = cs.surface,
        title = { Text(title, fontWeight = FontWeight.Bold) }, text = { Text(text, color = cs.onSurfaceVariant) },
        confirmButton = { TextButton(onOk) { Text("Xóa", color = StatusCol[0], fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(onClose) { Text("Hủy") } })

@Composable
fun EditBtn(onClick: () -> Unit) =
    IconButton(onClick, Modifier.size(30.dp)) { Icon(Icons.Default.Edit, "Sửa tên", tint = cs.onSurfaceVariant, modifier = Modifier.size(15.dp)) }

@Composable
fun TopBar(title: String, back: () -> Unit, onEdit: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    var show by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(back) { Icon(Icons.Default.ArrowBack, null, tint = cs.onSurface) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1,
            modifier = Modifier.weight(1f, fill = false).clip(RoundedCornerShape(8.dp)).clickable(enabled = onEdit != null) { show = !show }.padding(horizontal = 4.dp, vertical = 4.dp))
        if (onEdit != null && show) EditBtn { show = false; onEdit() }
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

// ---------- trang chủ ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Home(vm: AppVM, now: Long, open: (String) -> Unit, openPrj: (String, String) -> Unit, settings: () -> Unit) {
    val pager = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    val aiList = rememberLazyListState()
    val prjList = rememberLazyListState()
    val drag = remember { DragCtl(aiList, 1) { a, b -> vm.moveAi(a, b) } }
    var flt by rememberSaveable { mutableStateOf(-1) }
    var pickAi by remember { mutableStateOf<String?>(null) }
    var addAi by remember { mutableStateOf(false) }
    var addPrj by remember { mutableStateOf(false) }
    var editAi by remember { mutableStateOf<Ai?>(null) }
    var delAi by remember { mutableStateOf<Ai?>(null) }
    var editPrj by remember { mutableStateOf<Pair<Ai, Project>?>(null) }
    var delPrj by remember { mutableStateOf<Pair<Ai, Project>?>(null) }
    val allPrj = remember(vm.ais) { vm.ais.flatMap { a -> a.projects.map { a to it } }.sortedBy { it.second.status } }
    val shown = remember(allPrj, flt) { if (flt < 0) allPrj else allPrj.filter { it.second.status == flt } }
    val active = remember(vm.ais) { vm.ais.sumOf { a -> a.projects.count { it.status == 0 } } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 12.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text("AI Manager", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, letterSpacing = (-0.5).sp)
                Text("${vm.ais.size} AI · $active dự án pending", fontSize = 14.sp, color = cs.onSurfaceVariant)
            }
            IconButton(settings) { Icon(Icons.Default.Settings, null, tint = cs.onSurfaceVariant) }
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f), beyondViewportPageCount = 1, userScrollEnabled = drag.dragging < 0) { page ->
            if (page == 0) {
                Box(Modifier.fillMaxSize()) {
                    LazyColumn(state = prjList, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 0.dp, 20.dp, 90.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item(key = "hint") { Text("${allPrj.size} dự án · bấm để mở việc cần làm", fontSize = 13.sp, color = cs.onSurfaceVariant) }
                        item(key = "flt") {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(-1, 0, 2).forEach { s ->
                                    val n = if (s < 0) allPrj.size else allPrj.count { it.second.status == s }
                                    val c = if (s < 0) cs.onSurface else StatusCol[s]
                                    val sel = flt == s
                                    val pill = RoundedCornerShape(50)
                                    Text("${if (s < 0) "Tất cả" else StatusName[s]} · $n", color = if (sel) c else cs.onSurfaceVariant, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.clip(pill).background(if (sel) c.copy(alpha = .2f) else cs.surface).border(1.dp, if (sel) c.copy(alpha = .6f) else line, pill)
                                            .clickable { flt = s }.padding(horizontal = 14.dp, vertical = 6.dp))
                                }
                            }
                        }
                        if (shown.isEmpty()) item(key = "none") { Text("Chưa có dự án nào", color = cs.onSurfaceVariant, fontSize = 13.sp) }
                        items(shown, key = { it.second.id }) { (a, p) -> PrjCard(a, p, now, { openPrj(a.id, p.id) }, { vm.setCd(a.id, 0) }, { pickAi = a.id }, { editPrj = a to p }, { delPrj = a to p }) }
                    }
                    FloatingActionButton({ addPrj = true }, Modifier.align(Alignment.BottomEnd).padding(20.dp),
                        containerColor = cs.primary, contentColor = cs.onPrimary) { Icon(Icons.Default.Add, "Thêm dự án") }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    LazyColumn(state = aiList, modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 0.dp, 20.dp, 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item(key = "hint") {
                            Text(if (vm.ais.isEmpty()) "Chưa có AI nào. Bấm \"Thêm AI\" để bắt đầu." else "Kéo cụm chấm để sắp xếp · dấu ⋮ để đổi tên hoặc xóa",
                                fontSize = 13.sp, color = cs.onSurfaceVariant)
                        }
                        itemsIndexed(vm.ais, key = { _, a -> a.id }) { i, a ->
                            AiCard(a, i, now, drag, { editAi = a }, { delAi = a }) { open(a.id) }
                        }
                    }
                    Box(Modifier.padding(20.dp, 8.dp, 20.dp, 16.dp)) { BigButton("+  Thêm AI") { addAi = true } }
                }
            }
        }
        Box(Modifier.padding(20.dp, 6.dp, 20.dp, 12.dp)) {
            Segmented(listOf("Dự án", "AI"), pager.currentPage) { scope.launch { pager.animateScrollToPage(it) } }
        }
    }
    if (addAi) TextDialog("Thêm AI", "Tên AI", { addAi = false }) { vm.addAi(it); addAi = false }
    if (addPrj) AddProjectDialog(vm.ais, { addPrj = false }) { id, name -> vm.addPrj(id, name); addPrj = false }
    editAi?.let { e -> TextDialog("Sửa tên AI", "Tên AI", { editAi = null }, e.name) { vm.renameAi(e.id, it); editAi = null } }
    pickAi?.let { id -> CooldownPicker({ vm.setCd(id, it); pickAi = null }) { pickAi = null } }
    delAi?.let { d -> ConfirmDialog("Xóa AI “${d.name}”?", "Tất cả dự án và việc của AI này cũng sẽ bị xóa.", { vm.delAi(d.id); delAi = null }) { delAi = null } }
    editPrj?.let { (a, p) -> TextDialog("Sửa tên dự án", "Tên dự án", { editPrj = null }, p.name) { vm.renamePrj(a.id, p.id, it); editPrj = null } }
    delPrj?.let { (a, p) -> ConfirmDialog("Xóa dự án “${p.name}”?", "Các việc trong dự án cũng sẽ bị xóa.", { vm.delPrj(a.id, p.id); delPrj = null }) { delPrj = null } }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddProjectDialog(ais: List<Ai>, close: () -> Unit, ok: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf(ais.firstOrNull()?.id) }
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(26.dp), containerColor = cs.surface, title = { Text("Thêm dự án", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Tên dự án") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                if (ais.isEmpty()) Text("Chưa có AI nào. Hãy thêm AI ở trang AI trước.", color = cs.onSurfaceVariant, fontSize = 13.sp)
                else {
                    Text("Thuộc AI", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { ais.forEach { a -> FilterChip(sel == a.id, { sel = a.id }, { Text(a.name) }) } }
                }
            }
        },
        confirmButton = { TextButton({ val s = sel; if (name.isNotBlank() && s != null) ok(s, name.trim()) }) { Text("Thêm", fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(close) { Text("Hủy") } })
}

@Composable
fun AiStatePill(ready: Boolean, onReady: () -> Unit, onCool: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    val c = if (ready) Ready else Wait
    Box {
        Row(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .16f)).clickable { open = true }
            .padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).background(c, CircleShape)); Spacer(Modifier.width(6.dp))
            Text(if (ready) "Sẵn sàng" else "Đang hồi", color = c, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Icon(Icons.Default.ArrowDropDown, null, tint = c, modifier = Modifier.size(20.dp))
        }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem(text = { Text("Sẵn sàng", color = Ready, fontWeight = FontWeight.SemiBold) }, onClick = { onReady(); open = false })
            DropdownMenuItem(text = { Text("Đang hồi", color = Wait, fontWeight = FontWeight.SemiBold) }, onClick = { onCool(); open = false })
        }
    }
}

/** Thẻ dự án trong tab "Dự án": màu theo trạng thái dự án; bên phải là trạng thái AI đang làm dự án (đổi được). */
@Composable
fun PrjCard(a: Ai, p: Project, now: Long, onClick: () -> Unit, onReady: () -> Unit, onCool: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    val c = StatusCol[p.status]
    val shape = RoundedCornerShape(20.dp)
    val rest = left(a, now)
    val ready = rest == 0L
    val todo = p.todos.count { !it.done }
    Row(
        Modifier.fillMaxWidth().clip(shape).background(cs.surface, shape)
            .background(Brush.linearGradient(listOf(c.copy(alpha = .22f), Color.Transparent)), shape)
            .border(1.dp, c.copy(alpha = .7f), shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(p.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = if (p.status == 2) cs.onSurfaceVariant else cs.onSurface, maxLines = 2,
                textDecoration = if (p.status == 2) androidx.compose.ui.text.style.TextDecoration.LineThrough else null)
            Spacer(Modifier.height(1.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(if (ready) Ready else Wait, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text("AI: ${a.name}", fontSize = 14.sp, color = cs.onSurfaceVariant, maxLines = 1)
                if (!ready) Text("  ·  ${fmt(rest)}", style = tnum, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Wait, maxLines = 1)
                else if (todo > 0) Text("  ·  $todo việc", fontSize = 14.sp, color = cs.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(8.dp))
        AiStatePill(ready, onReady, onCool)
        MoreMenu(onRename, onDelete)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AiCard(a: Ai, i: Int, now: Long, drag: DragCtl, onRename: () -> Unit, onDelete: () -> Unit, onClick: () -> Unit) {
    val ready = left(a, now) == 0L
    val shape = RoundedCornerShape(20.dp)
    val hs = a.hotStatus()
    val hot = hs != null
    val hc = StatusCol[hs ?: 0]
    val act = a.active()
    Row(
        Modifier.fillMaxWidth().zIndex(if (drag.dragging == i) 1f else 0f)
            .graphicsLayer { translationY = if (drag.dragging == i) drag.dy else 0f }
            .clip(shape)
            .background(cs.surface, shape)
            .background(if (hot) Brush.linearGradient(listOf(hc.copy(alpha = .22f), Color.Transparent)) else SolidColor(Color.Transparent), shape)
            .border(if (hot) 1.5.dp else 1.dp, if (hot) SolidColor(hc.copy(alpha = .85f)) else SolidColor(line), shape)
            .clickable(onClick = onClick).padding(start = 4.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(36.dp, 44.dp).dragHandle(a.id, i, drag), contentAlignment = Alignment.Center) { Dots(cs.onSurfaceVariant.copy(alpha = .8f)) }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(a.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
            }
            if (act.isEmpty()) Text("Free", fontSize = 13.sp, color = cs.onSurfaceVariant)
            else Text(buildAnnotatedString {
                act.forEachIndexed { j, p ->
                    if (j > 0) append(" · ")
                    withStyle(SpanStyle(color = StatusCol[p.status], fontWeight = FontWeight.SemiBold)) { append(p.name) }
                }
            }, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Pill(ready)
            if (!ready) Text(fmt(left(a, now)), style = tnum, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp, end = 2.dp))
        }
        MoreMenu(onRename, onDelete)
    }
}

// ---------- hộp thoại ----------

@Composable
fun TextDialog(title: String, hint: String, close: () -> Unit, init: String = "", multiline: Boolean = false, ok: (String) -> Unit) {
    var t by remember { mutableStateOf(init) }
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(26.dp), containerColor = cs.surface, title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { OutlinedTextField(t, { t = it }, label = { Text(hint) }, singleLine = !multiline, maxLines = if (multiline) 6 else 1, shape = RoundedCornerShape(16.dp)) },
        confirmButton = { TextButton({ if (t.isNotBlank()) ok(t.trim()) }) { Text("OK", fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(close) { Text("Hủy") } })
}

@Composable
private fun PickField(label: String, value: String, onClick: () -> Unit) =
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surfaceVariant).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text(label, color = cs.onSurfaceVariant, fontSize = 13.sp)
        Text(value, color = cs.onSurface, fontSize = 18.sp, fontWeight = FontWeight.Bold, style = tnum)
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CooldownPicker(onDone: (Long) -> Unit, close: () -> Unit) {
    val zone = ZoneId.systemDefault()
    var date by remember { mutableStateOf(LocalDate.now()) }
    var time by remember { mutableStateOf(LocalTime.now().withSecond(0).withNano(0)) }
    var showD by remember { mutableStateOf(false) }
    var showT by remember { mutableStateOf(false) }
    val target = LocalDateTime.of(date, time).atZone(zone).toInstant().toEpochMilli()
    val now = System.currentTimeMillis()
    val valid = target > now
    val today = LocalDate.now()
    val dText = "%02d/%02d/%d".format(date.dayOfMonth, date.monthValue, date.year).let {
        when (date) { today -> "Hôm nay · $it"; today.plusDays(1) -> "Ngày mai · $it"; else -> it }
    }
    AlertDialog(onDismissRequest = close, shape = RoundedCornerShape(26.dp), containerColor = cs.surface,
        title = { Text("Giờ hồi chính xác", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PickField("Ngày", dText) { showD = true }
                PickField("Giờ", "%02d:%02d".format(time.hour, time.minute)) { showT = true }
                Text(if (valid) "Còn " + fmt(target - now) else "Thời điểm này đã qua, hãy chọn lại",
                    color = if (valid) cs.onSurfaceVariant else Wait, fontSize = 14.sp)
            }
        },
        confirmButton = { TextButton({ onDone(target) }, enabled = valid) { Text("Đặt", fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(close) { Text("Hủy") } })
    if (showD) {
        val st = rememberDatePickerState(initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(onDismissRequest = { showD = false },
            confirmButton = {
                TextButton({ st.selectedDateMillis?.let { date = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() }; showD = false }) { Text("OK") }
            },
            dismissButton = { TextButton({ showD = false }) { Text("Hủy") } }) { DatePicker(st) }
    }
    if (showT) {
        val ts = rememberTimePickerState(time.hour, time.minute, true)
        AlertDialog(onDismissRequest = { showT = false }, shape = RoundedCornerShape(26.dp), containerColor = cs.surface,
            title = { Text("Chọn giờ", fontWeight = FontWeight.Bold) },
            text = { TimePicker(ts) },
            confirmButton = { TextButton({ time = LocalTime.of(ts.hour, ts.minute); showT = false }) { Text("OK") } },
            dismissButton = { TextButton({ showT = false }) { Text("Hủy") } })
    }
}

// ---------- chi tiết AI ----------

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun Detail(vm: AppVM, a: Ai, now: Long, openPrj: (String) -> Unit, back: () -> Unit) {
    val ls = rememberLazyListState()
    val drag = remember(a.id) { DragCtl(ls, 3) { x, y -> vm.movePrj(a.id, x, y) } }
    var pick by remember { mutableStateOf(false) }
    var add by remember { mutableStateOf(false) }
    var editA by remember { mutableStateOf(false) }
    var delA by remember { mutableStateOf(false) }
    var delP by remember { mutableStateOf<Project?>(null) }
    var editP by remember { mutableStateOf<Project?>(null) }
    val ready = left(a, now) == 0L
    val col = if (ready) Ready else Wait
    Column(Modifier.fillMaxSize()) {
        LazyColumn(state = ls, modifier = Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item(key = "bar") {
                Row(Modifier.fillMaxWidth().padding(horizontal = 0.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(back) { Icon(Icons.Default.ArrowBack, null, tint = cs.onSurface) }
                    Spacer(Modifier.weight(1f))
                    MoreMenu({ editA = true }, { delA = true })
                }
            }
            item(key = "hero") {
                val shape = RoundedCornerShape(28.dp)
                val rest = left(a, now)
                val act = a.active()
                val mainPrj = act.firstOrNull() ?: a.projects.firstOrNull()
                val eta = Instant.ofEpochMilli(a.cooldownUntil).atZone(ZoneId.systemDefault())
                val etaText = "%02d:%02d".format(eta.hour, eta.minute) + if (eta.toLocalDate() != LocalDate.now()) " · %02d/%02d".format(eta.dayOfMonth, eta.monthValue) else ""
                val frac = if (a.cdStart > 0 && a.cooldownUntil > a.cdStart) ((now - a.cdStart).toFloat() / (a.cooldownUntil - a.cdStart)) else null
                Column(Modifier.fillMaxWidth().clip(shape).background(cs.surface, shape).border(1.dp, line, shape).padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(a.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, maxLines = 1,
                            modifier = Modifier.weight(1f, fill = false))
                        Spacer(Modifier.weight(1f))
                        Text(if (ready) "Sẵn sàng" else "Đang hồi", color = col, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(col.copy(alpha = .16f)).padding(horizontal = 14.dp, vertical = 6.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            if (ready) Text("READY", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = col)
                            else Text(fmt(rest), style = tnum, fontSize = 40.sp, fontWeight = FontWeight.Bold, color = col)
                            Text(if (ready) "Có thể sử dụng ngay" else "Thời gian còn lại", fontSize = 14.sp, color = cs.onSurfaceVariant)
                        }
                        Box(Modifier.size(64.dp).clip(RoundedCornerShape(20.dp)).background(cs.surfaceVariant).clickable { vm.setAiNotify(a.id, !a.notify) },
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Notifications, "Thông báo", tint = if (a.notify) Ready else cs.onSurfaceVariant.copy(alpha = .6f), modifier = Modifier.size(28.dp))
                        }
                    }
                    if (!ready) {
                        Spacer(Modifier.height(16.dp))
                        if (frac != null) { ProgressBar(frac, col); Spacer(Modifier.height(12.dp)) }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Dự kiến sẵn sàng", fontSize = 14.sp, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                            Text(etaText, style = tnum, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(line))
                    Row(Modifier.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Dự án đang hoạt động", fontSize = 15.sp, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                        Text("%02d".format(act.size), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
                    }
                    if (act.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        act.forEach { p ->
                            val c = StatusCol[p.status]
                            Text("${p.name} · ${StatusName[p.status]}", color = c, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .14f)).clickable { openPrj(p.id) }.padding(horizontal = 12.dp, vertical = 6.dp))
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TileButton(if (ready) "Đặt giờ hồi" else "Đổi giờ hồi", true, { pick = true }) { ClockIcon(cs.onSurface) }
                        TileButton("Mở dự án", mainPrj != null, { mainPrj?.let { openPrj(it.id) } }) { FolderIcon(cs.onSurface) }
                    }
                    if (!ready) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton({ vm.setCd(a.id, 0) }, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(24.dp)) {
                            Text("Đặt sẵn sàng ngay", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    if (a.notify) {
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Âm báo thức", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                                Text(if (vm.notify) "Kêu cả khi máy im lặng" else "Đang tắt thông báo chung trong Cài đặt", fontSize = 12.sp, color = cs.onSurfaceVariant)
                            }
                            Switch(a.loud, { vm.setAiLoud(a.id, it) })
                        }
                    }
                }
            }
            item(key = "pt") {
                Text("Dự án · kéo cụm chấm để sắp xếp · ★ là dự án chính", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
            }
            itemsIndexed(a.projects, key = { _, p -> p.id }) { i, p ->
                val shape = RoundedCornerShape(22.dp)
                Row(
                    Modifier.fillMaxWidth().zIndex(if (drag.dragging == i) 1f else 0f)
                        .graphicsLayer { translationY = if (drag.dragging == i) drag.dy else 0f }
                        .clip(shape).background(cs.surface).border(1.dp, if (i == 0) cs.primary.copy(alpha = .5f) else line, shape)
                        .clickable { openPrj(p.id) }
                        .padding(start = 6.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(40.dp, 48.dp).dragHandle(p.id, i, drag), contentAlignment = Alignment.Center) { Dots(cs.onSurfaceVariant.copy(alpha = .8f)) }
                    Text(if (i == 0) "★" else "${i + 1}", color = if (i == 0) cs.primary else cs.onSurfaceVariant, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = cs.onSurface, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            StatusPill(p.status)
                            if (p.todos.isNotEmpty()) Text("  ${p.todos.count { !it.done }}/${p.todos.size} việc", fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                    }
                    MoreMenu({ editP = p }, { delP = p })
                }
            }
        }
        Box(Modifier.padding(20.dp, 8.dp, 20.dp, 16.dp)) { BigButton("+  Thêm dự án") { add = true } }
    }
    if (pick) CooldownPicker({ vm.setCd(a.id, it); pick = false }) { pick = false }
    if (add) TextDialog("Thêm dự án", "Tên dự án", { add = false }) { vm.addPrj(a.id, it); add = false }
    if (editA) TextDialog("Sửa tên AI", "Tên AI", { editA = false }, a.name) { vm.renameAi(a.id, it); editA = false }
    editP?.let { p -> TextDialog("Sửa tên dự án", "Tên dự án", { editP = null }, p.name) { vm.renamePrj(a.id, p.id, it); editP = null } }
    if (delA) ConfirmDialog("Xóa AI “${a.name}”?", "Tất cả dự án và việc của AI này cũng sẽ bị xóa.", { delA = false; vm.delAi(a.id); back() }) { delA = false }
    delP?.let { p -> ConfirmDialog("Xóa dự án “${p.name}”?", "Các việc trong dự án cũng sẽ bị xóa.", { vm.delPrj(a.id, p.id); delP = null }) { delP = null } }
}

// ---------- todo của dự án ----------

@Composable
fun TodoRow(t: Todo, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val d = Instant.ofEpochMilli(t.createdAt).atZone(ZoneId.systemDefault())
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(32.dp).clickable(onClick = onToggle), contentAlignment = Alignment.Center) {
                Box(Modifier.size(22.dp).clip(CircleShape).border(2.dp, if (t.done) Ready else cs.onSurfaceVariant.copy(alpha = .7f), CircleShape),
                    contentAlignment = Alignment.Center) {
                    if (t.done) Icon(Icons.Default.Check, null, tint = Ready, modifier = Modifier.size(14.dp))
                }
            }
            Spacer(Modifier.width(8.dp))
            Text(t.text, modifier = Modifier.weight(1f).clickable(onClick = onEdit).padding(top = 6.dp, bottom = 4.dp), fontSize = 14.sp, lineHeight = 19.sp,
                color = if (t.done) cs.onSurfaceVariant else cs.onSurface,
                textDecoration = if (t.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null)
            Text("${d.monthValue}/${d.dayOfMonth}", style = tnum, fontSize = 11.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 9.dp))
            Box(Modifier.size(32.dp).clickable(onClick = onDelete), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Close, "Xóa", tint = cs.onSurfaceVariant.copy(alpha = .6f), modifier = Modifier.size(16.dp))
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(line))
    }
}

@Composable
fun TodoDialog(title: String, init: String, onClose: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(init) }
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (init.isEmpty()) fr.requestFocus() }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(.96f).fillMaxHeight(.9f), shape = RoundedCornerShape(22.dp), color = cs.surface) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(t, { t = it }, Modifier.weight(1f).fillMaxWidth().focusRequester(fr),
                    textStyle = TextStyle(fontSize = 13.sp, lineHeight = 18.sp),
                    placeholder = { Text("Nhập nội dung công việc…", fontSize = 13.sp) }, shape = RoundedCornerShape(16.dp))
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ clip.setText(AnnotatedString(t)); Toast.makeText(ctx, "Đã sao chép", Toast.LENGTH_SHORT).show() }) { Text("Sao chép") }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClose) { Text("Hủy") }
                    TextButton({ if (t.isNotBlank()) onOk(t.trim()) }, enabled = t.isNotBlank()) { Text("OK", fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
}

@Composable
fun ProjectScreen(vm: AppVM, ai: Ai, p: Project, back: () -> Unit) {
    var adding by remember { mutableStateOf(false) }
    var editT by remember { mutableStateOf<Todo?>(null) }
    var ren by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    val open = p.todos.filter { !it.done }.sortedByDescending { it.createdAt }
    val done = p.todos.filter { it.done }.sortedByDescending { it.doneAt }
    val pct = if (p.todos.isEmpty()) 0 else done.size * 100 / p.todos.size
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            @Suppress("DEPRECATION")
            val u = r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            vm.setPrjRingtone(ai.id, p.id, u?.toString() ?: "")
        }
    }
    val rtName = if (p.ringtone.isBlank()) "Mặc định" else (runCatching { RingtoneManager.getRingtone(ctx, Uri.parse(p.ringtone)).getTitle(ctx) }.getOrNull() ?: "Tùy chọn")
    if (adding) TodoDialog("Việc mới", "", { adding = false }) { vm.addTodo(ai.id, p.id, it); adding = false }
    editT?.let { e -> TodoDialog("Sửa việc", e.text, { editT = null }) { vm.editTodo(ai.id, p.id, e.id, it); editT = null } }
    if (ren) TextDialog("Sửa tên dự án", "Tên dự án", { ren = false }, p.name) { vm.renamePrj(ai.id, p.id, it); ren = false }
    if (del) ConfirmDialog("Xóa dự án “${p.name}”?", "Các việc trong dự án cũng sẽ bị xóa.", { del = false; vm.delPrj(ai.id, p.id); back() }) { del = false }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Default.ArrowBack, null, tint = cs.onSurface) }
            Spacer(Modifier.weight(1f))
            MoreMenu({ ren = true }, { del = true })
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(20.dp, 0.dp, 20.dp, 12.dp)) {
            item(key = "head") {
                Text(p.name, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = cs.onSurface)
                Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("AI: ${ai.name}  ·  ", fontSize = 15.sp, color = cs.onSurfaceVariant)
                    StatusPill(p.status)
                }
                Row(Modifier.padding(top = 14.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant).clickable {
                    picker.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Âm báo của dự án")
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        if (p.ringtone.isNotBlank()) putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(p.ringtone))
                    })
                }.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Âm báo", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = cs.onSurface)
                        Text("Khi AI hồi xong · $rtName", fontSize = 13.sp, color = cs.onSurfaceVariant, maxLines = 1)
                    }
                    Text("Đổi", color = cs.primary, fontWeight = FontWeight.SemiBold)
                }
                Row(Modifier.padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Tiến độ", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, modifier = Modifier.weight(1f))
                    Text("$pct%", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ready)
                }
                ProgressBar(pct / 100f, Ready)
                Spacer(Modifier.height(18.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(line))
                Row(Modifier.padding(top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Cần làm", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, modifier = Modifier.weight(1f))
                    Text("${open.size}", fontSize = 14.sp, color = cs.onSurfaceVariant)
                }
            }
            if (open.isEmpty()) item(key = "empty") { Text("Chưa có việc nào", color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp)) }
            items(open, key = { it.id }) { t -> TodoRow(t, { vm.toggleTodo(ai.id, p.id, t.id) }, { editT = t }, { vm.delTodo(ai.id, p.id, t.id) }) }
            if (done.isNotEmpty()) {
                item(key = "h2") {
                    Box(Modifier.padding(top = 18.dp).fillMaxWidth().height(1.dp).background(line))
                    Row(Modifier.padding(top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Đã hoàn thành", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, modifier = Modifier.weight(1f))
                        Text("${done.size}", fontSize = 14.sp, color = cs.onSurfaceVariant)
                    }
                }
                items(done, key = { it.id }) { t -> TodoRow(t, { vm.toggleTodo(ai.id, p.id, t.id) }, { editT = t }, { vm.delTodo(ai.id, p.id, t.id) }) }
            }
        }
        Box(Modifier.padding(20.dp, 8.dp, 20.dp, 16.dp)) { BigButton("+  Thêm công việc") { adding = true } }
    }
}

// ---------- cài đặt ----------

@Composable
fun SettingsScreen(vm: AppVM, ask: () -> Unit, back: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TopBar("Cài đặt", back)
        Column(Modifier.padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Giao diện", color = cs.onSurfaceVariant, fontSize = 14.sp)
            Segmented(listOf("Tự động", "Sáng", "Tối"), vm.mode) { vm.changeMode(it) }
            Text("Cỡ chữ", color = cs.onSurfaceVariant, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            Segmented(listOf("Nhỏ", "Vừa", "Lớn"), vm.fs) { vm.changeFs(it) }
            Text("Màu chủ đạo", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                palettes.forEachIndexed { i, p ->
                    Box(Modifier.size(52.dp).clip(CircleShape).background(Color(p.second))
                        .border(if (vm.pal == i) 3.dp else 0.dp, cs.onSurface, CircleShape).clickable { vm.changePal(i) })
                }
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Thông báo khi AI hồi xong", color = cs.onSurface, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Switch(vm.notify, { vm.changeNotify(it); if (it) ask() })
            }
            val sctx = LocalContext.current
            OutlinedButton({ Notifier.openLoudSettings(sctx) }, shape = RoundedCornerShape(14.dp)) { Text("Mở cài đặt âm thanh thông báo của app", fontSize = 13.sp) }
            Text("Widget", color = cs.onSurfaceVariant, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Text("Giữ lâu màn hình chính → Widget → AI Manager. Có 2 loại: \"Một AI\" và \"Tất cả AI\" (danh sách). Kéo giãn widget để đổi kích thước.",
                color = cs.onSurface, fontSize = 15.sp)
        }
    }
}
